import React from "react";
import { renderToBuffer } from "@react-pdf/renderer";
import { CvDraft } from "@/types";
import { CvPdfDocument } from "@/components/pdf/CvPdfDocument";

function slugifyName(name: string) {
  return (
    name
      .trim()
      .replace(/[^a-zA-Z\s-]/g, "")
      .split(/\s+/)
      .filter(Boolean)
      .join("_") || "CV1QAR_User"
  );
}

export const PDFService = {
  filenameFor(draft: CvDraft): string {
    return `${slugifyName(draft.personalInfo.fullName || "")}_CV.pdf`;
  },

  /**
   * Renders the CV to a real, selectable-text A4 PDF using @react-pdf/renderer
   * (not a rasterized screenshot). Throws on failure — callers should catch
   * and surface the friendly "we generated your CV but not the PDF yet"
   * message rather than a raw stack trace.
   */
  async generate(draft: CvDraft): Promise<Buffer> {
    const buffer = await renderToBuffer(React.createElement(CvPdfDocument, { draft }));
    return buffer;
  }
};
