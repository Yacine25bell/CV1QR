import { v4 as uuidv4 } from "uuid";
import { Order, PaymentStatus } from "@/types";
import { db } from "@/database/mockDb";

// ---------------------------------------------------------------------------
// PaymentService — the single integration point for a real payment
// provider. CV1QAR charges a fixed 1 QAR (100 fils) per CV.
//
// Swap the bodies of createPayment / verifyPayment / handleWebhook to call
// a real gateway once PAYMENT_API_KEY / PAYMENT_SECRET are set. The PDF
// route only ever trusts verifyPayment()'s return value — never a client-
// supplied "success" flag — so the integration point is exactly here.
// ---------------------------------------------------------------------------

const AMOUNT_MINOR = Number(process.env.PAYMENT_AMOUNT_MINOR || 100); // 1.00 QAR
const CURRENCY = (process.env.PAYMENT_CURRENCY as "QAR") || "QAR";
const PROVIDER = process.env.PAYMENT_PROVIDER || "mock";

export interface CreatePaymentResult {
  order: Order;
  // For a real provider this would be a checkout URL or client secret.
  clientAction: { type: "redirect" | "mock-confirm"; value: string };
}

export const PaymentService = {
  async createPayment(cvId: string): Promise<CreatePaymentResult> {
    const order: Order = {
      id: uuidv4(),
      cvId,
      amountMinor: AMOUNT_MINOR,
      currency: CURRENCY,
      status: "pending",
      paymentProvider: PROVIDER,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    db.orders.set(order.id, order);

    if (PROVIDER === "mock") {
      return {
        order,
        clientAction: { type: "mock-confirm", value: order.id }
      };
    }

    // --- Real integration point -----------------------------------------
    // const session = await gateway.checkoutSessions.create({
    //   amount: order.amountMinor,
    //   currency: order.currency,
    //   metadata: { orderId: order.id, cvId }
    // });
    // order.providerReference = session.id;
    // db.orders.set(order.id, order);
    // return { order, clientAction: { type: "redirect", value: session.url } };

    return {
      order,
      clientAction: { type: "mock-confirm", value: order.id }
    };
  },

  /**
   * Simulates the user completing (or failing) checkout. In the mock
   * provider this is called directly by the frontend's "Pay 1 QAR" button;
   * with a real provider this logic instead lives in handleWebhook, and the
   * frontend only ever polls verifyPayment().
   */
  async simulateOutcome(orderId: string, outcome: "succeeded" | "failed" | "cancelled"): Promise<Order> {
    const order = db.orders.get(orderId);
    if (!order) throw new Error("Order not found");
    order.status = outcome;
    order.updatedAt = new Date().toISOString();
    order.providerReference = order.providerReference || `mock_${orderId}`;
    db.orders.set(orderId, order);
    return order;
  },

  /**
   * The only function the PDF route should trust. Never take payment
   * success from the client directly — always re-check against the order
   * record (which, with a real provider, is only ever written by
   * handleWebhook after signature verification).
   */
  async verifyPayment(orderId: string): Promise<{ status: PaymentStatus; order: Order | null }> {
    const order = db.orders.get(orderId) ?? null;
    return { status: order?.status ?? "pending", order };
  },

  /**
   * Real providers call this from a webhook route
   * (app/api/payment/webhook/route.ts). Verify the signature using
   * PAYMENT_WEBHOOK_SECRET before trusting the payload.
   */
  async handleWebhook(rawBody: string, signature: string | null): Promise<{ ok: boolean }> {
    if (PROVIDER === "mock") return { ok: true };

    // --- Real integration point -----------------------------------------
    // const isValid = verifySignature(rawBody, signature, process.env.PAYMENT_WEBHOOK_SECRET);
    // if (!isValid) return { ok: false };
    // const event = JSON.parse(rawBody);
    // const order = db.orders.get(event.metadata.orderId);
    // if (order) {
    //   order.status = event.type === "payment.succeeded" ? "succeeded" : "failed";
    //   db.orders.set(order.id, order);
    // }

    return { ok: true };
  }
};
