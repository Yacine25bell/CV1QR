import { CvDraft, WorkExperience } from "@/types";
import { getCountryRules } from "@/country-rules";

// ---------------------------------------------------------------------------
// AIService — the single integration point for a real AI provider.
//
// Every method here is called ONLY from server-side code (API routes), so
// AI_API_KEY never reaches the browser. Swap the body of `callModel` to hit
// a real provider (Anthropic, OpenAI, etc.) when USE_MOCK_AI=false; the
// public methods (generateSummary, polishBullet, ...) and their contracts
// stay the same either way, so nothing above this file needs to change.
// ---------------------------------------------------------------------------

const USE_MOCK_AI = process.env.USE_MOCK_AI !== "false";

interface ModelCallArgs {
  system: string;
  prompt: string;
}

async function callModel({ system, prompt }: ModelCallArgs): Promise<string> {
  if (USE_MOCK_AI || !process.env.AI_API_KEY) {
    return mockCompletion(prompt);
  }

  // --- Real integration point -------------------------------------------
  // Example using the Anthropic Messages API. Uncomment and adjust once
  // AI_API_KEY / AI_MODEL are set in the environment.
  //
  // const response = await fetch("https://api.anthropic.com/v1/messages", {
  //   method: "POST",
  //   headers: {
  //     "content-type": "application/json",
  //     "x-api-key": process.env.AI_API_KEY!,
  //     "anthropic-version": "2023-06-01"
  //   },
  //   body: JSON.stringify({
  //     model: process.env.AI_MODEL || "claude-sonnet-4-6",
  //     max_tokens: 800,
  //     system,
  //     messages: [{ role: "user", content: prompt }]
  //   })
  // });
  // const data = await response.json();
  // return data.content?.[0]?.text ?? "";

  return mockCompletion(prompt);
}

// Extremely small heuristic "model" so the MVP is fully runnable offline.
// It rewords input without adding any new facts, numbers, or claims.
function mockCompletion(prompt: string): string {
  const sentenceStarters = [
    "Delivered",
    "Managed",
    "Coordinated",
    "Supported",
    "Handled",
    "Contributed to",
    "Maintained"
  ];
  const trimmed = prompt.trim();
  if (!trimmed) return "";
  const starter = sentenceStarters[trimmed.length % sentenceStarters.length];
  const body = trimmed
    .replace(/\.$/, "")
    .replace(/^i\s/i, "")
    .replace(/^(answer|handle|help|manage|do|work on)\s/i, "");
  return `${starter} ${body.charAt(0).toLowerCase()}${body.slice(1)}, ensuring consistent, professional results.`;
}

function systemPromptFor(draft: CvDraft): string {
  const rules = getCountryRules(draft.countrySlug);
  return [
    "You are a professional CV/resume writer.",
    "Rules you must always follow:",
    "1. Never fabricate information, employers, job titles, qualifications, achievements, dates, or certifications.",
    "2. Only rewrite, clarify, and professionalize what the user has actually provided.",
    "3. Improve grammar and word choice; do not exaggerate.",
    "4. Optimize keywords using only the user's real experience.",
    "5. Follow this country's conventions.",
    `Country: ${rules.displayName}. ${rules.aiPromptGuidance}`,
    `CV type: ${draft.cvType ?? "professional"}.`
  ].join("\n");
}

export const AIService = {
  async generateSummary(draft: CvDraft): Promise<string> {
    const system = systemPromptFor(draft);
    const experienceText = draft.experience
      .map((e) => `${e.jobTitle} at ${e.company}: ${e.responsibilities}`)
      .join(" | ");
    const prompt = `Write a 2-4 sentence professional summary based only on: ${experienceText || "no experience provided yet"}.`;
    return callModel({ system, prompt });
  },

  async polishExperience(draft: CvDraft, exp: WorkExperience): Promise<{ responsibilities: string; achievements: string }> {
    const system = systemPromptFor(draft);
    const responsibilities = await callModel({
      system,
      prompt: exp.responsibilities || ""
    });
    const achievements = exp.achievements
      ? await callModel({ system, prompt: exp.achievements })
      : "";
    return { responsibilities, achievements };
  },

  async suggestSkills(draft: CvDraft): Promise<string[]> {
    const text = draft.experience.map((e) => `${e.jobTitle} ${e.responsibilities}`).join(" ").toLowerCase();
    const catalogue: Record<string, string[]> = {
      customer: ["Customer Service", "Conflict Resolution", "CRM Software"],
      sales: ["Sales Negotiation", "Lead Generation", "Salesforce"],
      manage: ["Team Leadership", "Performance Management", "Budgeting"],
      data: ["Data Analysis", "Excel", "Reporting"],
      market: ["Digital Marketing", "SEO", "Content Strategy"],
      account: ["Bookkeeping", "Financial Reporting", "Reconciliation"],
      develop: ["Software Development", "Version Control (Git)", "Debugging"],
      teach: ["Curriculum Design", "Classroom Management", "Assessment Design"]
    };
    const found = new Set<string>();
    Object.entries(catalogue).forEach(([keyword, skills]) => {
      if (text.includes(keyword)) skills.forEach((s) => found.add(s));
    });
    if (found.size === 0) {
      ["Communication", "Problem Solving", "Time Management"].forEach((s) => found.add(s));
    }
    return Array.from(found);
  },

  async checkAtsCompatibility(draft: CvDraft): Promise<number> {
    // Simple deterministic heuristic for the MVP: rewards having the core
    // ATS-relevant sections filled in. Swap for a real model call later.
    let score = 40;
    if (draft.summary) score += 15;
    if (draft.experience.length > 0) score += 20;
    if (draft.education.length > 0) score += 10;
    if (draft.skills.some((g) => g.items.length > 0)) score += 15;
    return Math.min(score, 100);
  }
};
