import { v4 as uuidv4 } from "uuid";
import { CvDraft } from "@/types";
import { db } from "@/database/mockDb";

// Thin repository layer over the mock DB so API routes never touch `db`
// directly. Swap the bodies for real SQL queries when DATABASE_URL is wired
// up — the function signatures are the contract the rest of the app relies on.
export const CVService = {
  create(partial: Partial<CvDraft>): CvDraft {
    const now = new Date().toISOString();
    const draft: CvDraft = {
      id: uuidv4(),
      countrySlug: partial.countrySlug || "uk",
      cvType: partial.cvType ?? null,
      personalInfo: partial.personalInfo ?? {},
      summaryMode: partial.summaryMode ?? "manual",
      summary: partial.summary ?? "",
      experience: partial.experience ?? [],
      education: partial.education ?? [],
      skills: partial.skills ?? [],
      certifications: partial.certifications ?? [],
      additionalSections: partial.additionalSections ?? [],
      templateId: partial.templateId ?? "ats-classic",
      createdAt: now,
      updatedAt: now
    };
    db.cvs.set(draft.id, draft);
    db.track("cv_started", { countrySlug: draft.countrySlug, cvId: draft.id });
    return draft;
  },

  get(id: string): CvDraft | undefined {
    return db.cvs.get(id);
  },

  save(draft: CvDraft): CvDraft {
    draft.updatedAt = new Date().toISOString();
    db.cvs.set(draft.id, draft);
    return draft;
  },

  markCompleted(id: string) {
    const draft = db.cvs.get(id);
    if (draft) db.track("cv_completed", { countrySlug: draft.countrySlug, cvId: id });
  }
};
