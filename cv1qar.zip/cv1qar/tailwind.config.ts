import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Deep maroon accent (nods to the Qatar market this product launches in)
        maroon: {
          50: "#fbecef",
          100: "#f3d1d8",
          200: "#e3a3ae",
          300: "#cf7484",
          400: "#b64a5e",
          500: "#8a1538",
          600: "#75102f",
          700: "#5f0c26",
          800: "#4a081d",
          900: "#380515"
        },
        ink: {
          50: "#f4f5f7",
          100: "#e5e7eb",
          200: "#c7ccd4",
          300: "#9aa2b0",
          400: "#6b7383",
          500: "#454d5e",
          600: "#2f3644",
          700: "#1f2530",
          800: "#141821",
          900: "#0b0d13"
        },
        paper: "#FBFAF7",
        gold: "#C6A15B"
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        sans: ["var(--font-sans)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"]
      },
      boxShadow: {
        stamp: "0 1px 0 rgba(11,13,19,0.04), 0 8px 24px -12px rgba(11,13,19,0.25)"
      },
      backgroundImage: {
        grain: "radial-gradient(circle at 1px 1px, rgba(11,13,19,0.06) 1px, transparent 0)"
      }
    }
  },
  plugins: []
};
export default config;
