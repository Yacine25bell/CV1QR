import { CountryCvRules } from "./types";

export const ireland: CountryCvRules = {
  countrySlug: "ireland",
  displayName: "Ireland",
  prioritySections: ["summary", "experience", "education", "skills", "certifications"],
  optionalPersonalFields: [],
  discouragedFields: ["photo", "dateOfBirth", "maritalStatus"],
  conventionSummary:
    "Irish CVs follow UK-style conventions: summary-led, no photo, no personal details unrelated to the role.",
  aiPromptGuidance: "Follow UK-style conventions closely; omit personal identifiers.",
  defaultTemplateId: "modern-professional"
};

export default ireland;
