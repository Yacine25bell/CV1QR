import { CountryCvRules } from "./types";

export const italy: CountryCvRules = {
  countrySlug: "italy",
  displayName: "Italy",
  prioritySections: ["summary", "experience", "education", "skills", "languages"],
  optionalPersonalFields: ["photo", "dateOfBirth"],
  conventionSummary:
    "Italian CVs ('curriculum vitae') often include a photo and personal details, particularly in traditional sectors — both remain optional on CV1QAR.",
  aiPromptGuidance: "Photo and date of birth included only if explicitly supplied by the user.",
  defaultTemplateId: "modern-professional"
};

export default italy;
