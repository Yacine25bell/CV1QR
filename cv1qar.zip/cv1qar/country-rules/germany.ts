import { CountryCvRules } from "./types";

export const germany: CountryCvRules = {
  countrySlug: "germany",
  displayName: "Germany",
  prioritySections: ["personalInfo", "experience", "education", "skills", "certifications", "languages"],
  optionalPersonalFields: ["photo", "dateOfBirth", "nationality"],
  conventionSummary:
    "The traditional German 'Lebenslauf' includes a photo, date of birth, and nationality, though this is shifting toward the international style. CV1QAR offers a German-style layout while making every one of these fields clearly optional and explained in the wizard.",
  aiPromptGuidance:
    "Offer a tabular, precise style if the user selects the German-style option. Clearly mark photo, date of birth, and nationality as optional and only include what the user supplied.",
  defaultTemplateId: "executive"
};

export default germany;
