import { CountryCvRules } from "./types";

export const australia: CountryCvRules = {
  countrySlug: "australia",
  displayName: "Australia",
  prioritySections: ["summary", "experience", "education", "skills", "certifications", "references"],
  optionalPersonalFields: [],
  discouragedFields: ["photo", "dateOfBirth", "nationality", "maritalStatus"],
  conventionSummary:
    "Australian CVs are typically 2-3 pages, achievement-focused, and sometimes include referees on request.",
  aiPromptGuidance:
    "Allow slightly longer, more detailed role descriptions than the UK/US style. Referees are listed only if the user added them.",
  defaultTemplateId: "modern-professional"
};

export default australia;
