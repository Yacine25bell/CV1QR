import { CountryCvRules } from "./types";

export const spain: CountryCvRules = {
  countrySlug: "spain",
  displayName: "Spain",
  prioritySections: ["summary", "experience", "education", "skills", "languages"],
  optionalPersonalFields: ["photo", "dateOfBirth"],
  conventionSummary:
    "Spanish CVs traditionally include a photo and sometimes a date of birth, though this varies by industry — both remain optional here.",
  aiPromptGuidance: "Photo and date of birth included only if the user explicitly supplied them.",
  defaultTemplateId: "modern-professional"
};

export default spain;
