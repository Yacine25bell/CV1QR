import { CountryCvRules } from "./types";

export const kuwait: CountryCvRules = {
  countrySlug: "kuwait",
  displayName: "Kuwait",
  prioritySections: [
    "experience",
    "jobTitle",
    "employer",
    "education",
    "certifications",
    "skills",
    "languages",
    "contact"
  ],
  optionalPersonalFields: ["nationality", "dateOfBirth", "photo"],
  conventionSummary:
    "Kuwaiti employers commonly follow GCC conventions: experience-led CVs with optional personal details.",
  aiPromptGuidance: "Keep language formal and role-focused; do not add optional personal fields unprompted.",
  defaultTemplateId: "ats-classic"
};

export default kuwait;
