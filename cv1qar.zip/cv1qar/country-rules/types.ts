// Every country rule file exports one object of this shape. Keeping rules as
// small, isolated, data-only files (rather than one big switch statement)
// means an admin (or future admin UI) can add or edit a market without
// touching the generation pipeline itself.
export interface CountryCvRules {
  countrySlug: string;
  displayName: string;
  // Sections shown, in the order they should be prioritized in the layout.
  prioritySections: string[];
  // Personal fields the culture/market commonly includes, but that CV1QAR
  // never requires — the wizard renders these as opt-in only.
  optionalPersonalFields: Array<"photo" | "dateOfBirth" | "nationality" | "maritalStatus">;
  // Fields CV1QAR actively discourages/hides for this market (e.g. US/UK
  // anti-discrimination norms), shown as a one-line explainer in the UI.
  discouragedFields?: string[];
  // Short explainer shown on the country's SEO landing page and in the
  // wizard when this country is selected.
  conventionSummary: string;
  // Extra instruction text appended to the AI system prompt for this
  // market. Must stay within the global "never invent facts" rules.
  aiPromptGuidance: string;
  defaultTemplateId: "ats-classic" | "modern-professional" | "executive" | "minimal";
}
