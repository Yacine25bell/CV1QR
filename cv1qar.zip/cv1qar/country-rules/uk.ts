import { CountryCvRules } from "./types";

export const uk: CountryCvRules = {
  countrySlug: "uk",
  displayName: "United Kingdom",
  prioritySections: [
    "summary",
    "experience",
    "education",
    "skills",
    "certifications",
    "achievements",
    "linkedin"
  ],
  optionalPersonalFields: [],
  discouragedFields: ["photo", "dateOfBirth", "nationality", "maritalStatus"],
  conventionSummary:
    "UK CVs open with a short professional summary and generally omit a photo, date of birth, and other personal details not relevant to the role.",
  aiPromptGuidance:
    "Open with a 2-4 sentence professional summary. Do not include a photo, date of birth, nationality, or marital status.",
  defaultTemplateId: "modern-professional"
};

export default uk;
