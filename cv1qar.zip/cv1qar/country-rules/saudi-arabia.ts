import { CountryCvRules } from "./types";

export const saudiArabia: CountryCvRules = {
  countrySlug: "saudi-arabia",
  displayName: "Saudi Arabia",
  prioritySections: [
    "experience",
    "jobTitle",
    "employer",
    "education",
    "certifications",
    "skills",
    "languages",
    "contact"
  ],
  optionalPersonalFields: ["nationality", "dateOfBirth", "photo"],
  conventionSummary:
    "Saudi employers generally expect a formal, detailed work history and clearly listed qualifications. Personal details beyond contact info remain optional.",
  aiPromptGuidance:
    "Use a formal register. Group certifications clearly, as they are heavily weighted by Saudi employers and recruiters.",
  defaultTemplateId: "ats-classic"
};

export default saudiArabia;
