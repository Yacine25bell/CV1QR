import { CountryCvRules } from "./types";

export const qatar: CountryCvRules = {
  countrySlug: "qatar",
  displayName: "Qatar",
  prioritySections: [
    "experience",
    "jobTitle",
    "employer",
    "education",
    "certifications",
    "skills",
    "languages",
    "contact"
  ],
  optionalPersonalFields: ["nationality", "dateOfBirth", "photo"],
  conventionSummary:
    "Qatari and wider GCC employers typically expect a clear work-history-first CV. Nationality, date of birth, and a photo are common but optional — never required.",
  aiPromptGuidance:
    "Lead with job title and employer for each role. Keep tone formal. Do not add nationality, date of birth, or a photo unless the user provided them.",
  defaultTemplateId: "ats-classic"
};

export default qatar;
