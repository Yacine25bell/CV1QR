import { CountryCvRules } from "./types";

export const canada: CountryCvRules = {
  countrySlug: "canada",
  displayName: "Canada",
  prioritySections: ["summary", "experience", "education", "skills", "certifications"],
  optionalPersonalFields: [],
  discouragedFields: ["photo", "dateOfBirth", "nationality", "maritalStatus"],
  conventionSummary:
    "Canadian resumes follow North American conventions: ATS-friendly, no photo, and no personal details unrelated to the role.",
  aiPromptGuidance: "Follow standard North American resume structure. Never add a photo or personal identifiers.",
  defaultTemplateId: "ats-classic"
};

export default canada;
