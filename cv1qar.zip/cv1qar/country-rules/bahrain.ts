import { CountryCvRules } from "./types";

export const bahrain: CountryCvRules = {
  countrySlug: "bahrain",
  displayName: "Bahrain",
  prioritySections: [
    "experience",
    "jobTitle",
    "employer",
    "education",
    "certifications",
    "skills",
    "languages",
    "contact"
  ],
  optionalPersonalFields: ["nationality", "dateOfBirth", "photo"],
  conventionSummary:
    "Bahrain's job market follows regional GCC norms — experience-first CVs, optional personal details.",
  aiPromptGuidance: "Keep the tone professional and concise, matching regional expectations.",
  defaultTemplateId: "ats-classic"
};

export default bahrain;
