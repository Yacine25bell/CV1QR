import { CountryCvRules } from "./types";

export const netherlands: CountryCvRules = {
  countrySlug: "netherlands",
  displayName: "Netherlands",
  prioritySections: ["summary", "experience", "education", "skills", "languages"],
  optionalPersonalFields: ["photo"],
  conventionSummary:
    "Dutch CVs are direct and concise, usually one to two pages, with a photo as an optional but common addition.",
  aiPromptGuidance: "Favor a direct, no-frills tone. Photo optional.",
  defaultTemplateId: "minimal"
};

export default netherlands;
