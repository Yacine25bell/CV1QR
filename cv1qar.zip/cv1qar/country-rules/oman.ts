import { CountryCvRules } from "./types";

export const oman: CountryCvRules = {
  countrySlug: "oman",
  displayName: "Oman",
  prioritySections: [
    "experience",
    "jobTitle",
    "employer",
    "education",
    "certifications",
    "skills",
    "languages",
    "contact"
  ],
  optionalPersonalFields: ["nationality", "dateOfBirth", "photo"],
  conventionSummary:
    "Omani employers generally expect the same GCC-standard, experience-first CV structure with optional personal fields.",
  aiPromptGuidance: "Keep the tone formal and prioritize verified work history over personal details.",
  defaultTemplateId: "ats-classic"
};

export default oman;
