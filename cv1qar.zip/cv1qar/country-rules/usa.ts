import { CountryCvRules } from "./types";

export const usa: CountryCvRules = {
  countrySlug: "usa",
  displayName: "United States",
  prioritySections: ["summary", "experience", "education", "skills", "certifications"],
  optionalPersonalFields: [],
  discouragedFields: ["photo", "dateOfBirth", "nationality", "maritalStatus"],
  conventionSummary:
    "US resumes use a modern, ATS-friendly single-column structure and exclude a photo, date of birth, nationality, marital status, and religion.",
  aiPromptGuidance:
    "Structure as a modern ATS-friendly resume. Never add a photo, date of birth, nationality, marital status, or religion, even if provided — flag them back to the user as fields that are excluded for US applications.",
  defaultTemplateId: "ats-classic"
};

export default usa;
