import { CountryCvRules } from "./types";

export const france: CountryCvRules = {
  countrySlug: "france",
  displayName: "France",
  prioritySections: ["summary", "experience", "education", "skills", "languages"],
  optionalPersonalFields: ["photo"],
  conventionSummary:
    "French CVs ('CV') are typically one page, precise, and occasionally include a small photo — always optional on CV1QAR.",
  aiPromptGuidance: "Keep the CV to one page where possible. Photo included only if supplied by the user.",
  defaultTemplateId: "minimal"
};

export default france;
