import { CountryCvRules } from "./types";
import qatar from "./qatar";
import uae from "./uae";
import saudiArabia from "./saudi-arabia";
import kuwait from "./kuwait";
import bahrain from "./bahrain";
import oman from "./oman";
import uk from "./uk";
import usa from "./usa";
import canada from "./canada";
import australia from "./australia";
import germany from "./germany";
import france from "./france";
import netherlands from "./netherlands";
import ireland from "./ireland";
import spain from "./spain";
import italy from "./italy";

// Add a new market here after creating its country-rules/<slug>.ts file.
export const COUNTRY_RULES: Record<string, CountryCvRules> = {
  qatar,
  uae,
  "saudi-arabia": saudiArabia,
  kuwait,
  bahrain,
  oman,
  uk,
  usa,
  canada,
  australia,
  germany,
  france,
  netherlands,
  ireland,
  spain,
  italy
};

export function getCountryRules(slug: string): CountryCvRules {
  return COUNTRY_RULES[slug] ?? COUNTRY_RULES["uk"]; // sensible international default
}

export * from "./types";
