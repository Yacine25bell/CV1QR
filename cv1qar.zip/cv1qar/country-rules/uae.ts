import { CountryCvRules } from "./types";

export const uae: CountryCvRules = {
  countrySlug: "uae",
  displayName: "United Arab Emirates",
  prioritySections: [
    "experience",
    "jobTitle",
    "employer",
    "education",
    "certifications",
    "skills",
    "languages",
    "contact"
  ],
  optionalPersonalFields: ["nationality", "dateOfBirth", "photo"],
  conventionSummary:
    "UAE employers, especially in Dubai and Abu Dhabi, favor concise, achievement-oriented CVs. Visa status is sometimes mentioned but is entirely optional here.",
  aiPromptGuidance:
    "Favor a concise professional summary and quantify achievements only from what the user provided. Keep personal fields optional.",
  defaultTemplateId: "ats-classic"
};

export default uae;
