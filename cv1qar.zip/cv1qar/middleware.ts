import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";

export function middleware(req: NextRequest) {
  if (req.nextUrl.pathname === "/admin/login" || req.nextUrl.pathname.startsWith("/api/admin/login")) {
    return NextResponse.next();
  }

  if (req.nextUrl.pathname.startsWith("/admin") || req.nextUrl.pathname.startsWith("/api/admin")) {
    const token = req.cookies.get("cv1qar_admin")?.value;
    const secret = process.env.ADMIN_SESSION_SECRET || "change-me-too";
    const expected = crypto
      .createHmac("sha256", secret)
      .update(process.env.ADMIN_USERNAME || "admin")
      .digest("hex");

    if (token !== expected) {
      if (req.nextUrl.pathname.startsWith("/api/")) {
        return NextResponse.json({ error: "unauthorized" }, { status: 401 });
      }
      return NextResponse.redirect(new URL("/admin/login", req.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/api/admin/:path*"]
};
