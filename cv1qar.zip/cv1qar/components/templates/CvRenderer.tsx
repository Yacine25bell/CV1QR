import React from "react";
import { CvDraft, TemplateId } from "@/types";
import { getCountryRules } from "@/country-rules";

const ACCENTS: Record<TemplateId, string> = {
  "ats-classic": "#141821",
  "modern-professional": "#8A1538",
  executive: "#0b0d13",
  minimal: "#454d5e"
};

const HEADER_LAYOUT: Record<TemplateId, "left" | "center"> = {
  "ats-classic": "left",
  "modern-professional": "left",
  executive: "center",
  minimal: "left"
};

function formatRange(start: string, end: string, current: boolean) {
  return `${start || ""} — ${current ? "Present" : end || ""}`;
}

export function CvRenderer({ draft }: { draft: CvDraft }) {
  const accent = ACCENTS[draft.templateId];
  const align = HEADER_LAYOUT[draft.templateId];
  const rules = getCountryRules(draft.countrySlug);
  const info = draft.personalInfo;
  const showPhoto = Boolean(info.photoDataUrl) && rules.optionalPersonalFields.includes("photo");

  return (
    <div className="a4-page mx-auto p-10 text-[13px] leading-snug text-ink-800" style={{ fontFamily: "Georgia, serif" }}>
      <header className={`mb-6 flex ${align === "center" ? "flex-col items-center text-center" : "items-start justify-between"}`}>
        <div>
          <h1 className="font-sans text-2xl font-bold" style={{ color: accent }}>
            {info.fullName || "Your Name"}
          </h1>
          {info.professionalTitle ? <p className="mt-0.5 font-sans text-sm text-ink-500">{info.professionalTitle}</p> : null}
          <p className="mt-2 font-sans text-[11px] text-ink-400">
            {[info.email, info.phone, [info.city, info.country].filter(Boolean).join(", "), info.linkedinUrl, info.portfolioUrl]
              .filter(Boolean)
              .join("   ·   ")}
          </p>
          {rules.optionalPersonalFields.includes("nationality") && info.nationality ? (
            <p className="mt-1 font-sans text-[11px] text-ink-400">Nationality: {info.nationality}</p>
          ) : null}
          {rules.optionalPersonalFields.includes("dateOfBirth") && info.dateOfBirth ? (
            <p className="font-sans text-[11px] text-ink-400">Date of birth: {info.dateOfBirth}</p>
          ) : null}
        </div>
        {showPhoto ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={info.photoDataUrl} alt="" className="h-20 w-20 rounded-full object-cover" />
        ) : null}
      </header>

      {draft.summary ? (
        <Section title="Professional Summary" accent={accent}>
          <p>{draft.summary}</p>
        </Section>
      ) : null}

      {draft.experience.length ? (
        <Section title="Experience" accent={accent}>
          {draft.experience.map((exp) => (
            <div key={exp.id} className="mb-3">
              <div className="flex items-baseline justify-between font-sans">
                <span className="font-semibold">{exp.jobTitle || "Job Title"}</span>
                <span className="text-[11px] text-ink-400">{formatRange(exp.startDate, exp.endDate, exp.current)}</span>
              </div>
              <p className="font-sans text-[12px] text-ink-500">
                {exp.company}
                {exp.location ? ` · ${exp.location}` : ""}
              </p>
              {(exp.aiResponsibilities || exp.responsibilities) ? (
                <p className="mt-1">• {exp.aiResponsibilities || exp.responsibilities}</p>
              ) : null}
              {(exp.aiAchievements || exp.achievements) ? (
                <p className="mt-0.5">• {exp.aiAchievements || exp.achievements}</p>
              ) : null}
            </div>
          ))}
        </Section>
      ) : null}

      {draft.education.length ? (
        <Section title="Education" accent={accent}>
          {draft.education.map((ed) => (
            <div key={ed.id} className="mb-2">
              <div className="flex items-baseline justify-between font-sans">
                <span className="font-semibold">
                  {ed.degree}
                  {ed.fieldOfStudy ? `, ${ed.fieldOfStudy}` : ""}
                </span>
                <span className="text-[11px] text-ink-400">{formatRange(ed.startDate, ed.endDate, false)}</span>
              </div>
              <p className="font-sans text-[12px] text-ink-500">
                {ed.institution}
                {ed.location ? ` · ${ed.location}` : ""}
              </p>
            </div>
          ))}
        </Section>
      ) : null}

      {draft.skills.some((g) => g.items.length) ? (
        <Section title="Skills" accent={accent}>
          {draft.skills
            .filter((g) => g.items.length)
            .map((g) => (
              <p key={g.category} className="mb-1 font-sans text-[12px]">
                <span className="font-semibold capitalize">{g.category}: </span>
                {g.items.join(", ")}
              </p>
            ))}
        </Section>
      ) : null}

      {draft.certifications.length ? (
        <Section title="Certifications" accent={accent}>
          {draft.certifications.map((c) => (
            <p key={c.id} className="mb-1 font-sans text-[12px]">
              <span className="font-semibold">{c.name}</span> — {c.organization} {c.date ? `(${c.date})` : ""}
            </p>
          ))}
        </Section>
      ) : null}

      {draft.additionalSections
        .filter((s) => s.enabled && s.content)
        .map((s) => (
          <Section key={s.kind} title={sectionLabel(s.kind)} accent={accent}>
            <p>{s.content}</p>
          </Section>
        ))}
    </div>
  );
}

function Section({ title, accent, children }: { title: string; accent: string; children: React.ReactNode }) {
  return (
    <section className="mb-4">
      <h2
        className="mb-1.5 border-b pb-1 font-sans text-[11px] font-bold uppercase tracking-widest"
        style={{ color: accent, borderColor: accent }}
      >
        {title}
      </h2>
      {children}
    </section>
  );
}

function sectionLabel(kind: string) {
  const labels: Record<string, string> = {
    languages: "Languages",
    projects: "Projects",
    achievements: "Achievements",
    volunteer: "Volunteer Experience",
    memberships: "Professional Memberships",
    courses: "Courses",
    references: "References",
    publications: "Publications"
  };
  return labels[kind] || kind;
}
