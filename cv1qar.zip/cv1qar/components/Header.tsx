import Link from "next/link";

export function Header() {
  return (
    <header className="sticky top-0 z-10 border-b border-ink-100 bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
        <Link href="/" className="font-display text-lg font-bold text-ink-900">
          CV1QAR
        </Link>
        <Link
          href="/create"
          className="rounded-full bg-maroon-500 px-4 py-2 text-sm font-semibold text-white hover:bg-maroon-600"
        >
          Create My CV — 1 QAR
        </Link>
      </div>
    </header>
  );
}
