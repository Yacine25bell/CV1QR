import React from "react";

interface FieldProps {
  label: string;
  optional?: boolean;
  hint?: string;
  children: React.ReactNode;
}

export function Field({ label, optional, hint, children }: FieldProps) {
  return (
    <label className="mb-4 block">
      <span className="mb-1.5 flex items-baseline gap-2 text-sm font-semibold text-ink-700">
        {label}
        {optional ? <span className="text-xs font-normal text-ink-400">Optional</span> : null}
      </span>
      {children}
      {hint ? <span className="mt-1 block text-xs text-ink-400">{hint}</span> : null}
    </label>
  );
}

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`w-full rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm text-ink-800 outline-none transition-colors placeholder:text-ink-300 focus:border-maroon-500 ${
        props.className || ""
      }`}
    />
  );
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`w-full rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm text-ink-800 outline-none transition-colors placeholder:text-ink-300 focus:border-maroon-500 ${
        props.className || ""
      }`}
    />
  );
}

export function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-ink-100 bg-white p-6 shadow-stamp ${className}`}>{children}</div>
  );
}
