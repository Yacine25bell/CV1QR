import React from "react";

interface ProgressBarProps {
  step: number; // 1-indexed
  total: number;
  label: string;
}

export function ProgressBar({ step, total, label }: ProgressBarProps) {
  const pct = Math.round((step / total) * 100);
  return (
    <div className="mb-8">
      <div className="mb-2 flex items-center justify-between font-mono text-xs uppercase tracking-widest text-ink-400">
        <span>
          Step {step} of {total}
        </span>
        <span className="text-maroon-500">{label}</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-ink-100">
        <div
          className="h-full rounded-full bg-maroon-500 transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
