"use client";

import React from "react";

type Variant = "primary" | "secondary" | "ghost";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  fullWidth?: boolean;
}

const variants: Record<Variant, string> = {
  primary:
    "bg-maroon-500 text-white hover:bg-maroon-600 disabled:bg-ink-200 disabled:text-ink-400 shadow-stamp",
  secondary:
    "bg-white text-ink-800 border border-ink-200 hover:border-maroon-500 hover:text-maroon-500",
  ghost: "bg-transparent text-ink-600 hover:text-maroon-500"
};

export function Button({ variant = "primary", fullWidth, className = "", ...props }: ButtonProps) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-semibold transition-colors disabled:cursor-not-allowed ${
        variants[variant]
      } ${fullWidth ? "w-full" : ""} ${className}`}
      {...props}
    />
  );
}
