import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-ink-100 bg-white">
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row">
          <div>
            <p className="font-display text-lg font-semibold text-ink-900">CV1QAR</p>
            <p className="mt-1 max-w-xs text-sm text-ink-500">
              Country-specific, ATS-friendly CVs — generated in minutes, for 1 QAR.
            </p>
          </div>
          <div className="flex gap-8 text-sm text-ink-500">
            <div className="flex flex-col gap-2">
              <span className="font-semibold text-ink-700">Product</span>
              <Link href="/create" className="hover:text-maroon-500">
                Create a CV
              </Link>
              <Link href="/cv/qatar" className="hover:text-maroon-500">
                CV for Qatar
              </Link>
              <Link href="/cv/uk" className="hover:text-maroon-500">
                CV for UK
              </Link>
            </div>
            <div className="flex flex-col gap-2">
              <span className="font-semibold text-ink-700">Legal</span>
              <Link href="/privacy" className="hover:text-maroon-500">
                Privacy Policy
              </Link>
              <Link href="/terms" className="hover:text-maroon-500">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
        <p className="mt-8 text-xs text-ink-300">© {new Date().getFullYear()} CV1QAR. All rights reserved.</p>
      </div>
    </footer>
  );
}
