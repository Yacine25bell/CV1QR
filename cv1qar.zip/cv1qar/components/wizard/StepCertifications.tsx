"use client";

import React from "react";
import { v4 as uuidv4 } from "uuid";
import { Certification } from "@/types";
import { Field, TextInput, Card } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";

interface Props {
  value: Certification[];
  onChange: (v: Certification[]) => void;
}

function empty(): Certification {
  return { id: uuidv4(), name: "", organization: "", date: "" };
}

export function StepCertifications({ value, onChange }: Props) {
  const items = value;

  const update = (id: string, patch: Partial<Certification>) =>
    onChange(items.map((it) => (it.id === id ? { ...it, ...patch } : it)));
  const remove = (id: string) => onChange(items.filter((it) => it.id !== id));
  const add = () => onChange([...items, empty()]);

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">Certifications</h1>
      <p className="mb-6 text-sm text-ink-500">Optional — add any licenses or certifications you hold.</p>

      {items.length === 0 ? (
        <Button type="button" variant="secondary" onClick={add}>
          + Add a certification
        </Button>
      ) : (
        <div className="space-y-4">
          {items.map((c, idx) => (
            <Card key={c.id}>
              <div className="mb-3 flex items-center justify-between">
                <span className="font-mono text-xs uppercase tracking-widest text-ink-400">
                  Certification {idx + 1}
                </span>
                <button onClick={() => remove(c.id)} className="text-xs text-ink-400 hover:text-maroon-500">
                  Remove
                </button>
              </div>
              <div className="grid gap-x-4 sm:grid-cols-2">
                <Field label="Certification name">
                  <TextInput value={c.name} onChange={(e) => update(c.id, { name: e.target.value })} />
                </Field>
                <Field label="Issuing organization">
                  <TextInput value={c.organization} onChange={(e) => update(c.id, { organization: e.target.value })} />
                </Field>
                <Field label="Date">
                  <TextInput type="month" value={c.date} onChange={(e) => update(c.id, { date: e.target.value })} />
                </Field>
                <Field label="Expiration date" optional>
                  <TextInput
                    type="month"
                    value={c.expirationDate || ""}
                    onChange={(e) => update(c.id, { expirationDate: e.target.value })}
                  />
                </Field>
              </div>
            </Card>
          ))}
          <Button type="button" variant="ghost" onClick={add}>
            + Add Another Certification
          </Button>
        </div>
      )}
    </div>
  );
}
