"use client";

import React from "react";
import { CvType } from "@/types";

interface Props {
  value: CvType | null;
  onSelect: (t: CvType) => void;
}

const OPTIONS: Array<{ id: CvType; title: string; blurb: string }> = [
  { id: "professional", title: "Professional CV", blurb: "For experienced professionals." },
  { id: "ats", title: "ATS CV", blurb: "Optimized for applicant tracking systems." },
  { id: "graduate", title: "Graduate CV", blurb: "For students and recent graduates." },
  { id: "career-change", title: "Career Change CV", blurb: "For people changing industries." },
  { id: "executive", title: "Executive CV", blurb: "For managers and senior professionals." }
];

export function StepCvType({ value, onSelect }: Props) {
  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">
        What kind of CV do you need?
      </h1>
      <p className="mb-6 text-sm text-ink-500">This shapes structure, tone, and which sections lead.</p>
      <div className="grid gap-3 sm:grid-cols-2">
        {OPTIONS.map((opt) => (
          <button
            key={opt.id}
            onClick={() => onSelect(opt.id)}
            className={`rounded-2xl border p-5 text-left transition-all hover:-translate-y-0.5 hover:shadow-stamp ${
              value === opt.id ? "border-maroon-500 bg-maroon-50" : "border-ink-100 bg-white"
            }`}
          >
            <p className="font-display text-lg font-semibold text-ink-900">{opt.title}</p>
            <p className="mt-1 text-sm text-ink-500">{opt.blurb}</p>
          </button>
        ))}
      </div>
    </div>
  );
}
