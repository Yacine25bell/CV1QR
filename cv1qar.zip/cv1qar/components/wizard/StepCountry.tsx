"use client";

import React, { useMemo, useState } from "react";
import { COUNTRIES, FEATURED_COUNTRY_SLUGS } from "@/lib/countries";
import { Card } from "@/components/ui/Field";

interface Props {
  value: string;
  onSelect: (slug: string) => void;
}

export function StepCountry({ value, onSelect }: Props) {
  const [query, setQuery] = useState("");
  const [showAll, setShowAll] = useState(false);

  const featured = COUNTRIES.filter((c) => FEATURED_COUNTRY_SLUGS.includes(c.slug));
  const filtered = useMemo(
    () => COUNTRIES.filter((c) => c.name.toLowerCase().includes(query.toLowerCase())),
    [query]
  );

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">
        Where are you applying for jobs?
      </h1>
      <p className="mb-6 text-sm text-ink-500">
        We&apos;ll tailor structure, wording, and optional fields to this market&apos;s conventions.
      </p>

      {!showAll ? (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {featured.map((c) => (
              <button
                key={c.slug}
                onClick={() => onSelect(c.slug)}
                className={`flex flex-col items-center gap-2 rounded-2xl border p-4 text-center transition-all hover:-translate-y-0.5 hover:shadow-stamp ${
                  value === c.slug ? "border-maroon-500 bg-maroon-50" : "border-ink-100 bg-white"
                }`}
              >
                <span className="text-3xl">{c.flag}</span>
                <span className="text-sm font-medium text-ink-800">{c.name}</span>
              </button>
            ))}
          </div>
          <button
            className="mt-4 text-sm font-medium text-maroon-500 underline underline-offset-4"
            onClick={() => setShowAll(true)}
          >
            I don&apos;t see my country
          </button>
        </>
      ) : (
        <Card>
          <input
            autoFocus
            placeholder="Search countries…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="mb-4 w-full rounded-xl border border-ink-200 px-4 py-2.5 text-sm outline-none focus:border-maroon-500"
          />
          <div className="max-h-72 overflow-y-auto">
            {filtered.map((c) => (
              <button
                key={c.slug}
                onClick={() => onSelect(c.slug)}
                className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm hover:bg-ink-50 ${
                  value === c.slug ? "bg-maroon-50 text-maroon-600" : "text-ink-700"
                }`}
              >
                <span className="text-xl">{c.flag}</span>
                {c.name}
              </button>
            ))}
            {filtered.length === 0 ? (
              <p className="px-3 py-4 text-sm text-ink-400">No matches — more markets are added regularly.</p>
            ) : null}
          </div>
        </Card>
      )}
    </div>
  );
}
