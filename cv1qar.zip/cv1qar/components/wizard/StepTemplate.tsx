"use client";

import React from "react";
import { CvDraft, TemplateId } from "@/types";
import { CvRenderer } from "@/components/templates/CvRenderer";

interface Props {
  draft: CvDraft;
  onSelect: (id: TemplateId) => void;
}

const TEMPLATES: Array<{ id: TemplateId; name: string; blurb: string }> = [
  { id: "ats-classic", name: "ATS Classic", blurb: "Simple single-column design." },
  { id: "modern-professional", name: "Modern Professional", blurb: "Modern but ATS-friendly." },
  { id: "executive", name: "Executive", blurb: "Professional executive appearance." },
  { id: "minimal", name: "Minimal", blurb: "Clean and simple." }
];

export function StepTemplate({ draft, onSelect }: Props) {
  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">Choose a template</h1>
      <p className="mb-6 text-sm text-ink-500">
        Every template stays machine-readable — no tables, no graphics that confuse ATS parsers.
      </p>

      <div className="grid gap-5 sm:grid-cols-2">
        {TEMPLATES.map((t) => (
          <button
            key={t.id}
            onClick={() => onSelect(t.id)}
            className={`overflow-hidden rounded-2xl border text-left transition-all hover:-translate-y-0.5 hover:shadow-stamp ${
              draft.templateId === t.id ? "border-maroon-500 ring-2 ring-maroon-200" : "border-ink-100"
            }`}
          >
            <div className="h-56 overflow-hidden bg-ink-50">
              <div style={{ transform: "scale(0.32)", transformOrigin: "top left", width: "312.5%" }}>
                <CvRenderer draft={{ ...draft, templateId: t.id }} />
              </div>
            </div>
            <div className="p-4">
              <p className="font-display text-base font-semibold text-ink-900">{t.name}</p>
              <p className="text-xs text-ink-500">{t.blurb}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
