"use client";

import React, { useState } from "react";
import { CvDraft } from "@/types";
import { TextArea } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";

interface Props {
  draft: CvDraft;
  onChange: (patch: Partial<CvDraft>) => void;
}

export function StepSummary({ draft, onChange }: Props) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ type: "summary", draft })
      });
      if (!res.ok) throw new Error("failed");
      const data = await res.json();
      onChange({ summary: data.result, summaryMode: "ai" });
    } catch {
      setError("We couldn't generate your summary right now. Your information has been saved. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">Professional summary</h1>
      <p className="mb-6 text-sm text-ink-500">A short intro that sits at the top of your CV.</p>

      <div className="mb-4 inline-flex rounded-full bg-ink-50 p-1">
        <button
          onClick={() => onChange({ summaryMode: "manual" })}
          className={`rounded-full px-4 py-1.5 text-sm font-medium ${
            draft.summaryMode === "manual" ? "bg-white shadow-stamp text-ink-900" : "text-ink-500"
          }`}
        >
          Write it myself
        </button>
        <button
          onClick={() => onChange({ summaryMode: "ai" })}
          className={`rounded-full px-4 py-1.5 text-sm font-medium ${
            draft.summaryMode === "ai" ? "bg-white shadow-stamp text-ink-900" : "text-ink-500"
          }`}
        >
          Let AI create it
        </button>
      </div>

      {draft.summaryMode === "manual" ? (
        <TextArea
          rows={5}
          value={draft.summary}
          onChange={(e) => onChange({ summary: e.target.value })}
          placeholder="Results-driven professional with 5+ years of experience in…"
        />
      ) : (
        <div>
          <TextArea rows={5} value={draft.summary} onChange={(e) => onChange({ summary: e.target.value })} />
          <Button type="button" variant="secondary" className="mt-3" onClick={generate} disabled={loading}>
            {loading ? "Generating…" : "Generate with AI"}
          </Button>
          <p className="mt-2 text-xs text-ink-400">
            Built only from what you enter in the Work Experience step — nothing is invented.
          </p>
          {error ? <p className="mt-2 text-sm text-maroon-500">{error}</p> : null}
        </div>
      )}
    </div>
  );
}
