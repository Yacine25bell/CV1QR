"use client";

import React from "react";
import { v4 as uuidv4 } from "uuid";
import { Education } from "@/types";
import { Field, TextInput, TextArea, Card } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";

interface Props {
  value: Education[];
  onChange: (v: Education[]) => void;
}

function empty(): Education {
  return { id: uuidv4(), degree: "", institution: "", location: "", startDate: "", endDate: "" };
}

export function StepEducation({ value, onChange }: Props) {
  const items = value.length ? value : [empty()];

  const update = (id: string, patch: Partial<Education>) =>
    onChange(items.map((it) => (it.id === id ? { ...it, ...patch } : it)));
  const remove = (id: string) => onChange(items.filter((it) => it.id !== id));
  const add = () => onChange([...items, empty()]);

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">Education</h1>
      <p className="mb-6 text-sm text-ink-500">Add every degree or diploma relevant to your applications.</p>

      <div className="space-y-4">
        {items.map((ed, idx) => (
          <Card key={ed.id}>
            <div className="mb-3 flex items-center justify-between">
              <span className="font-mono text-xs uppercase tracking-widest text-ink-400">Education {idx + 1}</span>
              {items.length > 1 ? (
                <button onClick={() => remove(ed.id)} className="text-xs text-ink-400 hover:text-maroon-500">
                  Remove
                </button>
              ) : null}
            </div>
            <div className="grid gap-x-4 sm:grid-cols-2">
              <Field label="Degree">
                <TextInput value={ed.degree} onChange={(e) => update(ed.id, { degree: e.target.value })} />
              </Field>
              <Field label="Field of study" optional>
                <TextInput
                  value={ed.fieldOfStudy || ""}
                  onChange={(e) => update(ed.id, { fieldOfStudy: e.target.value })}
                />
              </Field>
              <Field label="Institution">
                <TextInput value={ed.institution} onChange={(e) => update(ed.id, { institution: e.target.value })} />
              </Field>
              <Field label="Location">
                <TextInput value={ed.location} onChange={(e) => update(ed.id, { location: e.target.value })} />
              </Field>
              <Field label="Start">
                <TextInput type="month" value={ed.startDate} onChange={(e) => update(ed.id, { startDate: e.target.value })} />
              </Field>
              <Field label="End">
                <TextInput type="month" value={ed.endDate} onChange={(e) => update(ed.id, { endDate: e.target.value })} />
              </Field>
            </div>
            <Field label="Additional information" optional>
              <TextArea
                rows={2}
                value={ed.additionalInfo || ""}
                onChange={(e) => update(ed.id, { additionalInfo: e.target.value })}
              />
            </Field>
          </Card>
        ))}
      </div>

      <Button type="button" variant="ghost" className="mt-4" onClick={add}>
        + Add Another Degree
      </Button>
    </div>
  );
}
