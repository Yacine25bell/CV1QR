"use client";

import React, { useEffect, useState } from "react";

const MESSAGES = [
  "Analyzing your experience",
  "Optimizing your professional summary",
  "Improving your job descriptions",
  "Organizing your skills",
  "Applying country-specific CV standards",
  "Checking ATS compatibility",
  "Preparing your CV"
];

export function StepGenerate({ onDone, failed }: { onDone: () => void; failed: boolean }) {
  const [visible, setVisible] = useState(0);

  useEffect(() => {
    if (visible >= MESSAGES.length) {
      const t = setTimeout(onDone, 500);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setVisible((v) => v + 1), 450);
    return () => clearTimeout(t);
  }, [visible, onDone]);

  if (failed) {
    return (
      <div className="py-16 text-center">
        <p className="mb-2 font-display text-xl font-semibold text-ink-900">We couldn&apos;t generate your CV right now.</p>
        <p className="text-sm text-ink-500">Your information has been saved. Please try again.</p>
      </div>
    );
  }

  return (
    <div className="py-10 text-center">
      <h1 className="mb-8 font-display text-2xl font-semibold text-ink-900">Creating your CV…</h1>
      <ul className="mx-auto max-w-xs space-y-3 text-left">
        {MESSAGES.map((m, i) => (
          <li
            key={m}
            className={`flex items-center gap-3 text-sm transition-opacity duration-300 ${
              i < visible ? "opacity-100 text-ink-800" : "opacity-30 text-ink-400"
            }`}
          >
            <span className={`flex h-5 w-5 items-center justify-center rounded-full text-xs ${
              i < visible ? "bg-maroon-500 text-white" : "bg-ink-100 text-ink-400"
            }`}>
              {i < visible ? "✓" : ""}
            </span>
            {m}
          </li>
        ))}
      </ul>
    </div>
  );
}
