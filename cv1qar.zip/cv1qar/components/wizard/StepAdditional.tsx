"use client";

import React from "react";
import { AdditionalSection, AdditionalSectionKind } from "@/types";
import { TextArea } from "@/components/ui/Field";

interface Props {
  value: AdditionalSection[];
  onChange: (v: AdditionalSection[]) => void;
}

const SECTIONS: Array<{ kind: AdditionalSectionKind; label: string; placeholder: string }> = [
  { kind: "languages", label: "Languages", placeholder: "Arabic (native), English (fluent)" },
  { kind: "projects", label: "Projects", placeholder: "Notable projects you've worked on" },
  { kind: "achievements", label: "Achievements", placeholder: "Awards, recognitions" },
  { kind: "volunteer", label: "Volunteer Experience", placeholder: "Organizations and roles" },
  { kind: "memberships", label: "Professional Memberships", placeholder: "Associations you belong to" },
  { kind: "courses", label: "Courses", placeholder: "Relevant courses completed" },
  { kind: "references", label: "References", placeholder: "Available on request, or list them" },
  { kind: "publications", label: "Publications", placeholder: "Papers, articles, books" }
];

function getSection(sections: AdditionalSection[], kind: AdditionalSectionKind): AdditionalSection {
  return sections.find((s) => s.kind === kind) || { kind, enabled: false, content: "" };
}

export function StepAdditional({ value, onChange }: Props) {
  function update(kind: AdditionalSectionKind, patch: Partial<AdditionalSection>) {
    const current = getSection(value, kind);
    const next = value.filter((s) => s.kind !== kind);
    onChange([...next, { ...current, ...patch }]);
  }

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">Additional sections</h1>
      <p className="mb-6 text-sm text-ink-500">Turn on anything else you&apos;d like on your CV.</p>

      <div className="space-y-4">
        {SECTIONS.map((s) => {
          const section = getSection(value, s.kind);
          return (
            <div key={s.kind} className="rounded-2xl border border-ink-100 p-4">
              <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink-800">
                <input
                  type="checkbox"
                  checked={section.enabled}
                  onChange={(e) => update(s.kind, { enabled: e.target.checked })}
                />
                {s.label}
              </label>
              {section.enabled ? (
                <TextArea
                  rows={2}
                  value={section.content}
                  onChange={(e) => update(s.kind, { content: e.target.value })}
                  placeholder={s.placeholder}
                />
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
