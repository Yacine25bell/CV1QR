"use client";

import React, { useRef } from "react";
import { PersonalInfo } from "@/types";
import { Field, TextInput } from "@/components/ui/Field";
import { getCountryRules } from "@/country-rules";

interface Props {
  countrySlug: string;
  value: Partial<PersonalInfo>;
  onChange: (v: Partial<PersonalInfo>) => void;
}

export function StepPersonalInfo({ countrySlug, value, onChange }: Props) {
  const rules = getCountryRules(countrySlug);
  const fileRef = useRef<HTMLInputElement>(null);

  const set = (patch: Partial<PersonalInfo>) => onChange({ ...value, ...patch });

  function handlePhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => set({ photoDataUrl: reader.result as string });
    reader.readAsDataURL(file);
  }

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">Personal information</h1>
      <p className="mb-6 text-sm text-ink-500">
        {rules.conventionSummary}
        {rules.discouragedFields?.length
          ? ` We leave out ${rules.discouragedFields.join(", ")} for this market.`
          : ""}
      </p>

      <div className="grid gap-x-4 sm:grid-cols-2">
        <Field label="Full name">
          <TextInput
            value={value.fullName || ""}
            onChange={(e) => set({ fullName: e.target.value })}
            placeholder="Fatima Al-Sayed"
            required
          />
        </Field>
        <Field label="Professional title">
          <TextInput
            value={value.professionalTitle || ""}
            onChange={(e) => set({ professionalTitle: e.target.value })}
            placeholder="Marketing Manager"
          />
        </Field>
        <Field label="Email">
          <TextInput
            type="email"
            value={value.email || ""}
            onChange={(e) => set({ email: e.target.value })}
            placeholder="you@example.com"
          />
        </Field>
        <Field label="Phone">
          <TextInput
            value={value.phone || ""}
            onChange={(e) => set({ phone: e.target.value })}
            placeholder="+974 5555 5555"
          />
        </Field>
        <Field label="City">
          <TextInput value={value.city || ""} onChange={(e) => set({ city: e.target.value })} placeholder="Doha" />
        </Field>
        <Field label="Country">
          <TextInput
            value={value.country || ""}
            onChange={(e) => set({ country: e.target.value })}
            placeholder="Qatar"
          />
        </Field>
        <Field label="LinkedIn URL" optional>
          <TextInput
            value={value.linkedinUrl || ""}
            onChange={(e) => set({ linkedinUrl: e.target.value })}
            placeholder="linkedin.com/in/you"
          />
        </Field>
        <Field label="Portfolio URL" optional>
          <TextInput
            value={value.portfolioUrl || ""}
            onChange={(e) => set({ portfolioUrl: e.target.value })}
            placeholder="yourportfolio.com"
          />
        </Field>

        {rules.optionalPersonalFields.includes("nationality") ? (
          <Field label="Nationality" optional>
            <TextInput
              value={value.nationality || ""}
              onChange={(e) => set({ nationality: e.target.value })}
              placeholder="Qatari"
            />
          </Field>
        ) : null}

        {rules.optionalPersonalFields.includes("dateOfBirth") ? (
          <Field label="Date of birth" optional>
            <TextInput
              type="date"
              value={value.dateOfBirth || ""}
              onChange={(e) => set({ dateOfBirth: e.target.value })}
            />
          </Field>
        ) : null}
      </div>

      {rules.optionalPersonalFields.includes("photo") ? (
        <Field label="Profile photo" optional hint="JPG or PNG, shown only if you add one.">
          <div className="flex items-center gap-4">
            {value.photoDataUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={value.photoDataUrl} alt="" className="h-16 w-16 rounded-full object-cover" />
            ) : null}
            <input ref={fileRef} type="file" accept="image/*" onChange={handlePhoto} className="text-sm" />
          </div>
        </Field>
      ) : null}
    </div>
  );
}
