"use client";

import React, { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { CvDraft, WorkExperience } from "@/types";
import { Field, TextInput, TextArea, Card } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";

interface Props {
  draft: CvDraft;
  onChange: (experience: WorkExperience[]) => void;
}

function emptyExperience(): WorkExperience {
  return {
    id: uuidv4(),
    jobTitle: "",
    company: "",
    location: "",
    startDate: "",
    endDate: "",
    current: false,
    responsibilities: "",
    achievements: ""
  };
}

export function StepExperience({ draft, onChange }: Props) {
  const [polishingId, setPolishingId] = useState<string | null>(null);
  const items = draft.experience.length ? draft.experience : [emptyExperience()];

  function update(id: string, patch: Partial<WorkExperience>) {
    onChange(items.map((it) => (it.id === id ? { ...it, ...patch } : it)));
  }

  function remove(id: string) {
    onChange(items.filter((it) => it.id !== id));
  }

  function add() {
    onChange([...items, emptyExperience()]);
  }

  async function polish(exp: WorkExperience) {
    setPolishingId(exp.id);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ type: "experience", draft, experienceId: exp.id })
      });
      if (!res.ok) throw new Error("failed");
      const data = await res.json();
      update(exp.id, { aiResponsibilities: data.responsibilities, aiAchievements: data.achievements });
    } catch {
      // Friendly failure — the raw text the user typed remains usable.
    } finally {
      setPolishingId(null);
    }
  }

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">Work experience</h1>
      <p className="mb-6 text-sm text-ink-500">
        Add every relevant role. AI can strengthen the wording — it never invents companies, titles, or numbers.
      </p>

      <div className="space-y-4">
        {items.map((exp, idx) => (
          <Card key={exp.id}>
            <div className="mb-3 flex items-center justify-between">
              <span className="font-mono text-xs uppercase tracking-widest text-ink-400">Position {idx + 1}</span>
              {items.length > 1 ? (
                <button onClick={() => remove(exp.id)} className="text-xs text-ink-400 hover:text-maroon-500">
                  Remove
                </button>
              ) : null}
            </div>

            <div className="grid gap-x-4 sm:grid-cols-2">
              <Field label="Job title">
                <TextInput value={exp.jobTitle} onChange={(e) => update(exp.id, { jobTitle: e.target.value })} />
              </Field>
              <Field label="Company">
                <TextInput value={exp.company} onChange={(e) => update(exp.id, { company: e.target.value })} />
              </Field>
              <Field label="Location">
                <TextInput value={exp.location} onChange={(e) => update(exp.id, { location: e.target.value })} />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Start">
                  <TextInput
                    type="month"
                    value={exp.startDate}
                    onChange={(e) => update(exp.id, { startDate: e.target.value })}
                  />
                </Field>
                <Field label="End">
                  <TextInput
                    type="month"
                    disabled={exp.current}
                    value={exp.endDate}
                    onChange={(e) => update(exp.id, { endDate: e.target.value })}
                  />
                </Field>
              </div>
            </div>

            <label className="mb-3 mt-1 flex items-center gap-2 text-sm text-ink-600">
              <input
                type="checkbox"
                checked={exp.current}
                onChange={(e) => update(exp.id, { current: e.target.checked })}
              />
              I currently work here
            </label>

            <Field label="Responsibilities">
              <TextArea
                rows={3}
                value={exp.responsibilities}
                onChange={(e) => update(exp.id, { responsibilities: e.target.value })}
                placeholder="Answer calls and help customers…"
              />
            </Field>
            <Field label="Achievements" optional>
              <TextArea
                rows={2}
                value={exp.achievements}
                onChange={(e) => update(exp.id, { achievements: e.target.value })}
                placeholder="Anything you're proud of in this role"
              />
            </Field>

            {exp.aiResponsibilities ? (
              <div className="mb-3 rounded-xl bg-maroon-50 p-3 text-sm text-ink-700">
                <p className="mb-1 font-mono text-xs uppercase tracking-widest text-maroon-500">AI-polished</p>
                <p>{exp.aiResponsibilities}</p>
                {exp.aiAchievements ? <p className="mt-1">{exp.aiAchievements}</p> : null}
              </div>
            ) : null}

            <Button
              type="button"
              variant="secondary"
              onClick={() => polish(exp)}
              disabled={polishingId === exp.id || !exp.responsibilities}
            >
              {polishingId === exp.id ? "Polishing…" : "Improve wording with AI"}
            </Button>
          </Card>
        ))}
      </div>

      <Button type="button" variant="ghost" className="mt-4" onClick={add}>
        + Add Another Position
      </Button>
    </div>
  );
}
