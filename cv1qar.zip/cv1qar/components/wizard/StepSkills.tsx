"use client";

import React, { useState } from "react";
import { CvDraft, SkillGroup } from "@/types";
import { Button } from "@/components/ui/Button";
import { TextInput } from "@/components/ui/Field";

interface Props {
  draft: CvDraft;
  onChange: (skills: SkillGroup[]) => void;
}

const CATEGORIES: SkillGroup["category"][] = [
  "technical",
  "software",
  "administrative",
  "communication",
  "management",
  "industry",
  "languages"
];

function getGroup(skills: SkillGroup[], category: SkillGroup["category"]): SkillGroup {
  return skills.find((g) => g.category === category) || { category, items: [] };
}

export function StepSkills({ draft, onChange }: Props) {
  const [draftInput, setDraftInput] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  function addSkill(category: SkillGroup["category"]) {
    const text = (draftInput[category] || "").trim();
    if (!text) return;
    const group = getGroup(draft.skills, category);
    const next = draft.skills.filter((g) => g.category !== category);
    onChange([...next, { category, items: [...group.items, text] }]);
    setDraftInput({ ...draftInput, [category]: "" });
  }

  function removeSkill(category: SkillGroup["category"], item: string) {
    const group = getGroup(draft.skills, category);
    const next = draft.skills.filter((g) => g.category !== category);
    onChange([...next, { category, items: group.items.filter((i) => i !== item) }]);
  }

  async function suggest() {
    setLoading(true);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ type: "skills", draft })
      });
      const data = await res.json();
      const group = getGroup(draft.skills, "technical");
      const merged = Array.from(new Set([...group.items, ...(data.result as string[])]));
      onChange([...draft.skills.filter((g) => g.category !== "technical"), { category: "technical", items: merged }]);
    } catch {
      // AI failures here are non-blocking — skills can still be added manually.
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">Skills</h1>
      <p className="mb-6 text-sm text-ink-500">Group your skills the way recruiters scan for them.</p>

      <Button type="button" variant="secondary" onClick={suggest} disabled={loading} className="mb-6">
        {loading ? "Suggesting…" : "Suggest skills with AI"}
      </Button>

      <div className="grid gap-5 sm:grid-cols-2">
        {CATEGORIES.map((cat) => {
          const group = getGroup(draft.skills, cat);
          return (
            <div key={cat}>
              <p className="mb-2 text-sm font-semibold capitalize text-ink-700">{cat}</p>
              <div className="mb-2 flex flex-wrap gap-2">
                {group.items.map((item) => (
                  <span
                    key={item}
                    className="flex items-center gap-1 rounded-full bg-ink-50 px-3 py-1 text-xs text-ink-700"
                  >
                    {item}
                    <button onClick={() => removeSkill(cat, item)} className="text-ink-400 hover:text-maroon-500">
                      ×
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <TextInput
                  value={draftInput[cat] || ""}
                  onChange={(e) => setDraftInput({ ...draftInput, [cat]: e.target.value })}
                  onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addSkill(cat))}
                  placeholder="Add a skill and press enter"
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
