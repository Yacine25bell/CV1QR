import React from "react";
import { Document, Page, Text, View, StyleSheet, Font } from "@react-pdf/renderer";
import { CvDraft, TemplateId } from "@/types";
import { getCountryRules } from "@/country-rules";

// Selectable-text, ATS-friendly PDF output. Deliberately avoids tables,
// multi-column layouts, and text-in-images — all of which confuse ATS
// parsers — regardless of which visual template is selected.

const accentByTemplate: Record<TemplateId, string> = {
  "ats-classic": "#141821",
  "modern-professional": "#8A1538",
  executive: "#0b0d13",
  minimal: "#454d5e"
};

const styles = StyleSheet.create({
  page: {
    paddingTop: 36,
    paddingBottom: 44,
    paddingHorizontal: 40,
    fontSize: 10.5,
    fontFamily: "Helvetica",
    color: "#141821"
  },
  name: { fontSize: 20, fontFamily: "Helvetica-Bold", marginBottom: 2 },
  title: { fontSize: 12, marginBottom: 8 },
  contactRow: { flexDirection: "row", flexWrap: "wrap", marginBottom: 12, fontSize: 9, color: "#454d5e" },
  contactItem: { marginRight: 10 },
  sectionTitle: {
    fontSize: 11,
    fontFamily: "Helvetica-Bold",
    marginTop: 14,
    marginBottom: 6,
    textTransform: "uppercase",
    letterSpacing: 0.6
  },
  rule: { borderBottomWidth: 1, borderBottomColor: "#c7ccd4", marginBottom: 8 },
  itemTitle: { fontSize: 10.5, fontFamily: "Helvetica-Bold" },
  itemSubtitle: { fontSize: 10, color: "#454d5e", marginBottom: 2 },
  itemDates: { fontSize: 9, color: "#6b7383", marginBottom: 4 },
  paragraph: { fontSize: 10, lineHeight: 1.5, marginBottom: 6 },
  bullet: { fontSize: 10, lineHeight: 1.45, marginBottom: 3, paddingLeft: 10 },
  skillsRow: { flexDirection: "row", flexWrap: "wrap" },
  skillChip: { fontSize: 9, marginRight: 6, marginBottom: 4 },
  pageNumber: {
    position: "absolute",
    bottom: 18,
    left: 0,
    right: 0,
    textAlign: "center",
    fontSize: 8,
    color: "#9aa2b0"
  }
});

function formatRange(start: string, end: string, current: boolean) {
  const fmt = (v: string) => v || "";
  return `${fmt(start)} — ${current ? "Present" : fmt(end)}`;
}

export function CvPdfDocument({ draft }: { draft: CvDraft }) {
  const accent = accentByTemplate[draft.templateId] || "#141821";
  const rules = getCountryRules(draft.countrySlug);
  const info = draft.personalInfo;
  const showPhoto = Boolean(info.photoDataUrl) && rules.optionalPersonalFields.includes("photo");

  return (
    <Document
      title={`${info.fullName || "CV"} - CV1QAR`}
      author={info.fullName || "CV1QAR"}
      subject="Curriculum Vitae"
    >
      <Page size="A4" style={styles.page} wrap>
        <Text style={[styles.name, { color: accent }]}>{info.fullName || "Your Name"}</Text>
        {info.professionalTitle ? <Text style={styles.title}>{info.professionalTitle}</Text> : null}

        <View style={styles.contactRow}>
          {info.email ? <Text style={styles.contactItem}>{info.email}</Text> : null}
          {info.phone ? <Text style={styles.contactItem}>{info.phone}</Text> : null}
          {info.city ? <Text style={styles.contactItem}>{info.city}{info.country ? `, ${info.country}` : ""}</Text> : null}
          {info.linkedinUrl ? <Text style={styles.contactItem}>{info.linkedinUrl}</Text> : null}
          {info.portfolioUrl ? <Text style={styles.contactItem}>{info.portfolioUrl}</Text> : null}
          {rules.optionalPersonalFields.includes("nationality") && info.nationality ? (
            <Text style={styles.contactItem}>Nationality: {info.nationality}</Text>
          ) : null}
          {rules.optionalPersonalFields.includes("dateOfBirth") && info.dateOfBirth ? (
            <Text style={styles.contactItem}>DOB: {info.dateOfBirth}</Text>
          ) : null}
        </View>

        {draft.summary ? (
          <View>
            <Text style={[styles.sectionTitle, { color: accent }]}>Professional Summary</Text>
            <View style={[styles.rule, { borderBottomColor: accent }]} />
            <Text style={styles.paragraph}>{draft.summary}</Text>
          </View>
        ) : null}

        {draft.experience.length > 0 ? (
          <View>
            <Text style={[styles.sectionTitle, { color: accent }]}>Experience</Text>
            <View style={[styles.rule, { borderBottomColor: accent }]} />
            {draft.experience.map((exp) => (
              <View key={exp.id} wrap={false} style={{ marginBottom: 8 }}>
                <Text style={styles.itemTitle}>{exp.jobTitle || "Job Title"}</Text>
                <Text style={styles.itemSubtitle}>
                  {exp.company}
                  {exp.location ? ` · ${exp.location}` : ""}
                </Text>
                <Text style={styles.itemDates}>{formatRange(exp.startDate, exp.endDate, exp.current)}</Text>
                {(exp.aiResponsibilities || exp.responsibilities) ? (
                  <Text style={styles.bullet}>• {exp.aiResponsibilities || exp.responsibilities}</Text>
                ) : null}
                {(exp.aiAchievements || exp.achievements) ? (
                  <Text style={styles.bullet}>• {exp.aiAchievements || exp.achievements}</Text>
                ) : null}
              </View>
            ))}
          </View>
        ) : null}

        {draft.education.length > 0 ? (
          <View>
            <Text style={[styles.sectionTitle, { color: accent }]}>Education</Text>
            <View style={[styles.rule, { borderBottomColor: accent }]} />
            {draft.education.map((ed) => (
              <View key={ed.id} wrap={false} style={{ marginBottom: 8 }}>
                <Text style={styles.itemTitle}>
                  {ed.degree}
                  {ed.fieldOfStudy ? `, ${ed.fieldOfStudy}` : ""}
                </Text>
                <Text style={styles.itemSubtitle}>
                  {ed.institution}
                  {ed.location ? ` · ${ed.location}` : ""}
                </Text>
                <Text style={styles.itemDates}>{formatRange(ed.startDate, ed.endDate, false)}</Text>
                {ed.additionalInfo ? <Text style={styles.paragraph}>{ed.additionalInfo}</Text> : null}
              </View>
            ))}
          </View>
        ) : null}

        {draft.skills.some((g) => g.items.length) ? (
          <View>
            <Text style={[styles.sectionTitle, { color: accent }]}>Skills</Text>
            <View style={[styles.rule, { borderBottomColor: accent }]} />
            {draft.skills
              .filter((g) => g.items.length)
              .map((g) => (
                <View key={g.category} style={{ marginBottom: 4 }}>
                  <Text style={[styles.itemSubtitle, { textTransform: "capitalize" }]}>{g.category}</Text>
                  <View style={styles.skillsRow}>
                    {g.items.map((item) => (
                      <Text key={item} style={styles.skillChip}>
                        {item}
                        {"  ·"}
                      </Text>
                    ))}
                  </View>
                </View>
              ))}
          </View>
        ) : null}

        {draft.certifications.length > 0 ? (
          <View>
            <Text style={[styles.sectionTitle, { color: accent }]}>Certifications</Text>
            <View style={[styles.rule, { borderBottomColor: accent }]} />
            {draft.certifications.map((c) => (
              <View key={c.id} style={{ marginBottom: 4 }}>
                <Text style={styles.itemTitle}>{c.name}</Text>
                <Text style={styles.itemDates}>
                  {c.organization} {c.date ? `· ${c.date}` : ""}
                  {c.expirationDate ? ` (expires ${c.expirationDate})` : ""}
                </Text>
              </View>
            ))}
          </View>
        ) : null}

        {draft.additionalSections
          .filter((s) => s.enabled && s.content)
          .map((s) => (
            <View key={s.kind}>
              <Text style={[styles.sectionTitle, { color: accent }]}>{sectionLabel(s.kind)}</Text>
              <View style={[styles.rule, { borderBottomColor: accent }]} />
              <Text style={styles.paragraph}>{s.content}</Text>
            </View>
          ))}

        <Text
          style={styles.pageNumber}
          render={({ pageNumber, totalPages }) => (totalPages > 1 ? `${pageNumber} / ${totalPages}` : "")}
          fixed
        />
      </Page>
    </Document>
  );
}

function sectionLabel(kind: string) {
  const labels: Record<string, string> = {
    languages: "Languages",
    projects: "Projects",
    achievements: "Achievements",
    volunteer: "Volunteer Experience",
    memberships: "Professional Memberships",
    courses: "Courses",
    references: "References",
    publications: "Publications"
  };
  return labels[kind] || kind;
}
