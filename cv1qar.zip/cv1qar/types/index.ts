// ---------------------------------------------------------------------------
// Shared types for CV1QAR. Mirrors the database structure in
// /database/schema.sql so the frontend, mock DB, and API routes agree on
// one shape for a CV.
// ---------------------------------------------------------------------------

export type CvType =
  | "professional"
  | "ats"
  | "graduate"
  | "career-change"
  | "executive";

export type TemplateId = "ats-classic" | "modern-professional" | "executive" | "minimal";

export type PaymentStatus = "pending" | "succeeded" | "failed" | "cancelled";

export interface Country {
  code: string; // ISO 3166-1 alpha-2, e.g. "qa"
  slug: string; // used in /cv/[country] URLs, e.g. "qatar"
  name: string;
  flag: string; // emoji flag
  region: "gcc" | "europe" | "north-america" | "oceania";
}

export interface PersonalInfo {
  fullName: string;
  professionalTitle: string;
  email: string;
  phone: string;
  city: string;
  country: string;
  linkedinUrl?: string;
  portfolioUrl?: string;
  photoDataUrl?: string; // optional, only rendered where the country rules allow it
  nationality?: string; // optional, GCC-style CVs only
  dateOfBirth?: string; // optional, GCC/DE-style CVs only
}

export interface WorkExperience {
  id: string;
  jobTitle: string;
  company: string;
  location: string;
  startDate: string; // YYYY-MM
  endDate: string; // YYYY-MM, ignored when current is true
  current: boolean;
  responsibilities: string; // raw user input
  achievements: string; // raw user input
  aiResponsibilities?: string; // AI-polished version, never invents new facts
  aiAchievements?: string;
}

export interface Education {
  id: string;
  degree: string;
  institution: string;
  location: string;
  startDate: string;
  endDate: string;
  fieldOfStudy?: string;
  additionalInfo?: string;
}

export interface SkillGroup {
  category:
    | "technical"
    | "software"
    | "administrative"
    | "communication"
    | "management"
    | "industry"
    | "languages";
  items: string[];
}

export interface Certification {
  id: string;
  name: string;
  organization: string;
  date: string;
  expirationDate?: string;
}

export type AdditionalSectionKind =
  | "languages"
  | "projects"
  | "achievements"
  | "volunteer"
  | "memberships"
  | "courses"
  | "references"
  | "publications";

export interface AdditionalSection {
  kind: AdditionalSectionKind;
  enabled: boolean;
  content: string; // free-text; kept simple for the MVP
}

export interface CvDraft {
  id: string;
  countrySlug: string;
  cvType: CvType | null;
  personalInfo: Partial<PersonalInfo>;
  summaryMode: "manual" | "ai";
  summary: string;
  experience: WorkExperience[];
  education: Education[];
  skills: SkillGroup[];
  certifications: Certification[];
  additionalSections: AdditionalSection[];
  templateId: TemplateId;
  aiGeneratedSummary?: string;
  atsScore?: number;
  createdAt: string;
  updatedAt: string;
}

export interface Order {
  id: string;
  cvId: string;
  amountMinor: number; // 100 = 1.00 QAR
  currency: "QAR";
  status: PaymentStatus;
  paymentProvider: string;
  providerReference?: string;
  createdAt: string;
  updatedAt: string;
}

export interface GeneratedFile {
  id: string;
  orderId: string;
  cvId: string;
  filename: string;
  storagePath: string; // never a publicly world-readable path
  createdAt: string;
  expiresAt?: string;
}

export const WIZARD_STEPS = [
  "country",
  "cv-type",
  "personal-info",
  "summary",
  "experience",
  "education",
  "skills",
  "certifications",
  "additional",
  "template",
  "generate",
  "preview"
] as const;

export type WizardStep = (typeof WIZARD_STEPS)[number];
