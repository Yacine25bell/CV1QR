import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata = { title: "Privacy Policy — CV1QAR" };

export default function PrivacyPage() {
  return (
    <>
      <Header />
      <main className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <h1 className="mb-6 font-display text-3xl font-semibold text-ink-900">Privacy Policy</h1>
        <div className="space-y-5 text-sm leading-relaxed text-ink-600">
          <p>
            CV1QAR collects the information you enter to build your CV (name, contact details, work history,
            education, and any optional fields you choose to add) and processes payment for the 1 QAR generation
            fee. This is a template policy for the MVP — replace it with counsel-reviewed language before launch.
          </p>
          <p>
            <strong className="text-ink-800">What we collect:</strong> the CV content you provide, basic usage
            analytics (country selected, steps completed, no CV content), and payment confirmation from our
            payment provider. We do not collect more personal information than a section requires, and every
            personal field marked optional stays optional.
          </p>
          <p>
            <strong className="text-ink-800">How we use it:</strong> to generate your CV, process your payment, and
            improve the product. We do not sell your CV information to third parties.
          </p>
          <p>
            <strong className="text-ink-800">Storage:</strong> generated CV files are stored privately and are not
            publicly accessible. Download links are private to your session.
          </p>
          <p>
            <strong className="text-ink-800">Your rights:</strong> you can request deletion of your account and CV
            data at any time by contacting us. We will remove your data except where retention is required by law
            (e.g. payment records).
          </p>
          <p>
            <strong className="text-ink-800">Contact:</strong> for privacy requests, reach us at
            privacy@cv1qar.example.
          </p>
        </div>
      </main>
      <Footer />
    </>
  );
}
