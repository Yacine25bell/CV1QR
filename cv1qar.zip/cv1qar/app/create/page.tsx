"use client";

import React, { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CvDraft, WIZARD_STEPS, WizardStep } from "@/types";
import { localDraftStore } from "@/lib/storage";
import { track } from "@/lib/analytics";
import { getCountryRules } from "@/country-rules";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { Button } from "@/components/ui/Button";
import { StepCountry } from "@/components/wizard/StepCountry";
import { StepCvType } from "@/components/wizard/StepCvType";
import { StepPersonalInfo } from "@/components/wizard/StepPersonalInfo";
import { StepSummary } from "@/components/wizard/StepSummary";
import { StepExperience } from "@/components/wizard/StepExperience";
import { StepEducation } from "@/components/wizard/StepEducation";
import { StepSkills } from "@/components/wizard/StepSkills";
import { StepCertifications } from "@/components/wizard/StepCertifications";
import { StepAdditional } from "@/components/wizard/StepAdditional";
import { StepTemplate } from "@/components/wizard/StepTemplate";
import { StepGenerate } from "@/components/wizard/StepGenerate";

const FORM_STEPS: WizardStep[] = [
  "country",
  "cv-type",
  "personal-info",
  "summary",
  "experience",
  "education",
  "skills",
  "certifications",
  "additional",
  "template"
];

const STEP_LABELS: Record<WizardStep, string> = {
  country: "Country",
  "cv-type": "CV Type",
  "personal-info": "Personal Information",
  summary: "Summary",
  experience: "Experience",
  education: "Education",
  skills: "Skills",
  certifications: "Certifications",
  additional: "Additional Sections",
  template: "Template",
  generate: "Generating",
  preview: "Preview"
};

function newDraft(): CvDraft {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    countrySlug: "",
    cvType: null,
    personalInfo: {},
    summaryMode: "manual",
    summary: "",
    experience: [],
    education: [],
    skills: [],
    certifications: [],
    additionalSections: [],
    templateId: "ats-classic",
    createdAt: now,
    updatedAt: now
  };
}

export default function CreatePage() {
  const router = useRouter();
  const params = useSearchParams();
  const [draft, setDraft] = useState<CvDraft>(newDraft());
  const [stepIndex, setStepIndex] = useState(0);
  const [mode, setMode] = useState<"form" | "generate">("form");
  const [genFailed, setGenFailed] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  // Restore autosaved progress on mount.
  useEffect(() => {
    const saved = localDraftStore.load();
    const preset = params.get("country");
    if (saved) {
      setDraft(saved);
      const savedStep = localDraftStore.loadStep();
      const idx = FORM_STEPS.indexOf((savedStep as WizardStep) || "country");
      setStepIndex(idx >= 0 ? idx : 0);
    } else if (preset) {
      setDraft((d) => ({ ...d, countrySlug: preset }));
      setStepIndex(1);
    }
    setHydrated(true);
    track("visitor");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localDraftStore.save(draft);
    localDraftStore.saveStep(FORM_STEPS[stepIndex]);
  }, [draft, stepIndex, hydrated]);

  function update(patch: Partial<CvDraft>) {
    setDraft((d) => ({ ...d, ...patch, updatedAt: new Date().toISOString() }));
  }

  function next() {
    if (stepIndex === 0) track("country_selected", { countrySlug: draft.countrySlug });
    if (stepIndex < FORM_STEPS.length - 1) {
      setStepIndex((i) => i + 1);
    } else {
      setMode("generate");
      runGeneration();
    }
  }

  function back() {
    if (stepIndex > 0) setStepIndex((i) => i - 1);
  }

  async function runGeneration() {
    setGenFailed(false);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ type: "finalize", draft })
      });
      if (!res.ok) throw new Error("failed");
      const data = await res.json();
      const saveRes = await fetch(`/api/cv/${draft.id}`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ...draft, atsScore: data.atsScore })
      }).catch(() => null);
      track("cv_completed", { countrySlug: draft.countrySlug, cvId: draft.id });
    } catch {
      setGenFailed(true);
    }
  }

  function handleGenerationDone() {
    localDraftStore.save(draft);
    router.push(`/preview?cvId=${draft.id}`);
  }

  const step = FORM_STEPS[stepIndex];
  const rules = draft.countrySlug ? getCountryRules(draft.countrySlug) : null;

  const canContinue = (): boolean => {
    switch (step) {
      case "country":
        return Boolean(draft.countrySlug);
      case "cv-type":
        return Boolean(draft.cvType);
      case "personal-info":
        return Boolean(draft.personalInfo.fullName);
      default:
        return true;
    }
  };

  if (mode === "generate") {
    return (
      <div className="mx-auto max-w-lg px-4 py-16">
        <StepGenerate onDone={handleGenerationDone} failed={genFailed} />
        {genFailed ? (
          <div className="text-center">
            <Button onClick={runGeneration}>Try Again</Button>
          </div>
        ) : null}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:py-16">
      <ProgressBar step={stepIndex + 1} total={FORM_STEPS.length} label={STEP_LABELS[step]} />

      <div className="mb-10">
        {step === "country" && (
          <StepCountry value={draft.countrySlug} onSelect={(slug) => { update({ countrySlug: slug }); }} />
        )}
        {step === "cv-type" && <StepCvType value={draft.cvType} onSelect={(t) => update({ cvType: t })} />}
        {step === "personal-info" && (
          <StepPersonalInfo
            countrySlug={draft.countrySlug}
            value={draft.personalInfo}
            onChange={(v) => update({ personalInfo: v })}
          />
        )}
        {step === "summary" && <StepSummary draft={draft} onChange={update} />}
        {step === "experience" && (
          <StepExperience draft={draft} onChange={(experience) => update({ experience })} />
        )}
        {step === "education" && <StepEducation value={draft.education} onChange={(education) => update({ education })} />}
        {step === "skills" && <StepSkills draft={draft} onChange={(skills) => update({ skills })} />}
        {step === "certifications" && (
          <StepCertifications value={draft.certifications} onChange={(certifications) => update({ certifications })} />
        )}
        {step === "additional" && (
          <StepAdditional value={draft.additionalSections} onChange={(additionalSections) => update({ additionalSections })} />
        )}
        {step === "template" && (
          <StepTemplate draft={draft} onSelect={(templateId) => update({ templateId })} />
        )}
      </div>

      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={back} disabled={stepIndex === 0} className={stepIndex === 0 ? "invisible" : ""}>
          ← Back
        </Button>
        <Button onClick={next} disabled={!canContinue()}>
          {stepIndex === FORM_STEPS.length - 1 ? "Generate My CV" : "Continue"}
        </Button>
      </div>
    </div>
  );
}
