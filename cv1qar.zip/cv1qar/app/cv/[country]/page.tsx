import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { getCountryBySlug, COUNTRIES } from "@/lib/countries";
import { getCountryRules } from "@/country-rules";

export function generateStaticParams() {
  return COUNTRIES.map((c) => ({ country: c.slug }));
}

export function generateMetadata({ params }: { params: { country: string } }) {
  const country = getCountryBySlug(params.country);
  if (!country) return {};
  return {
    title: `CV for ${country.name} — CV1QAR`,
    description: `Create a professional, ATS-friendly CV tailored to ${country.name} for only 1 QAR.`
  };
}

export default function CountryLandingPage({ params }: { params: { country: string } }) {
  const country = getCountryBySlug(params.country);
  if (!country) return notFound();
  const rules = getCountryRules(country.slug);

  return (
    <>
      <Header />
      <main className="mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-24">
        <p className="mb-2 text-5xl">{country.flag}</p>
        <h1 className="font-display text-3xl font-semibold text-ink-900 sm:text-4xl">
          CV for {country.name}, made for 1 QAR
        </h1>
        <p className="mt-4 text-base text-ink-600">{rules.conventionSummary}</p>

        <div className="mt-8 rounded-2xl border border-ink-100 bg-white p-6">
          <p className="mb-3 font-display text-lg font-semibold text-ink-900">What we prioritize</p>
          <ul className="grid grid-cols-2 gap-2 text-sm text-ink-600">
            {rules.prioritySections.map((s) => (
              <li key={s} className="flex items-center gap-2">
                <span className="text-maroon-500">✓</span>
                <span className="capitalize">{s.replace(/([A-Z])/g, " $1")}</span>
              </li>
            ))}
          </ul>
          {rules.discouragedFields?.length ? (
            <p className="mt-4 text-xs text-ink-400">
              We leave out: {rules.discouragedFields.join(", ")} — not expected for {country.name} applications.
            </p>
          ) : null}
        </div>

        <Link
          href={`/create?country=${country.slug}`}
          className="mt-8 inline-block rounded-full bg-maroon-500 px-8 py-3.5 text-base font-semibold text-white shadow-stamp hover:bg-maroon-600"
        >
          Create My {country.name} CV — 1 QAR
        </Link>

        <p className="mt-10 text-xs text-ink-400">
          CV1QAR helps you create a professional application document. It does not guarantee employment.
        </p>
      </main>
      <Footer />
    </>
  );
}
