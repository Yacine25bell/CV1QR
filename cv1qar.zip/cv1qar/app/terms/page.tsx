import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata = { title: "Terms of Service — CV1QAR" };

export default function TermsPage() {
  return (
    <>
      <Header />
      <main className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <h1 className="mb-6 font-display text-3xl font-semibold text-ink-900">Terms of Service</h1>
        <div className="space-y-5 text-sm leading-relaxed text-ink-600">
          <p>
            This is a template Terms of Service for the CV1QAR MVP — replace with counsel-reviewed language before
            launch.
          </p>
          <p>
            <strong className="text-ink-800">The service:</strong> CV1QAR generates a CV/resume document based on
            information you provide, for a fee of 1 QAR per CV. The service helps you create a professional
            application document; it does not guarantee employment or interviews.
          </p>
          <p>
            <strong className="text-ink-800">Accuracy:</strong> you are responsible for the accuracy of the
            information you provide. Our AI writing assistance only rewords and organizes what you enter — it does
            not add employers, qualifications, achievements, or dates you did not provide.
          </p>
          <p>
            <strong className="text-ink-800">Payment:</strong> the CV is unlocked for download only after your
            payment of 1 QAR is confirmed successful. Failed or cancelled payments are not charged.
          </p>
          <p>
            <strong className="text-ink-800">Refunds:</strong> because the PDF is generated and delivered
            immediately after payment, the fee is generally non-refundable once the file has been downloaded.
          </p>
          <p>
            <strong className="text-ink-800">Acceptable use:</strong> you agree not to use CV1QAR to submit
            fraudulent or knowingly false information in any application.
          </p>
        </div>
      </main>
      <Footer />
    </>
  );
}
