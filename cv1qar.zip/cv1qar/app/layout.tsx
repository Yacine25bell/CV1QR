import type { Metadata } from "next";
import "./globals.css";

// metadataBase must be a URL, resolved from an env var at request time so
// previews/staging never leak a hardcoded production domain.
export function generateMetadata(): Metadata {
  const url = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
  return {
    title: "AI CV Generator — Create a Professional CV for 1 QAR",
    description:
      "Create a professional, ATS-friendly CV tailored to your target country for only 1 QAR. Generate and download your CV in minutes.",
    metadataBase: new URL(url),
    openGraph: {
      title: "CV1QAR — Create Your Professional CV for Just 1 QAR",
      description: "Country-specific. ATS-friendly. Professional. Ready in minutes.",
      type: "website"
    }
  };
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
