import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { COUNTRIES } from "@/lib/countries";

const HOW_IT_WORKS = [
  { title: "Pick your market", blurb: "Select the country you're applying in — we adapt structure and tone to it." },
  { title: "Tell us about you", blurb: "Add your experience, education, and skills. AI can help polish the wording." },
  { title: "Pay 1 QAR & download", blurb: "Preview your CV, choose a template, and get a searchable PDF instantly." }
];

const WHY = [
  { title: "Country-specific", blurb: "Structure and tone matched to what employers expect in each market." },
  { title: "ATS-friendly", blurb: "Clean, single-column layouts that applicant tracking systems can parse." },
  { title: "Fast", blurb: "Go from blank page to a finished, downloadable CV in minutes." },
  { title: "Affordable", blurb: "One clear price — 1 QAR — no subscriptions, no hidden fees." }
];

const TEMPLATES = [
  { name: "ATS Classic", blurb: "Simple single-column design." },
  { name: "Modern Professional", blurb: "Modern but ATS-friendly." },
  { name: "Executive", blurb: "Professional executive appearance." },
  { name: "Minimal", blurb: "Clean and simple." }
];

const FAQ = [
  {
    q: "Is the CV really only 1 QAR?",
    a: "Yes. The standard CV generation service costs 1 QAR, subject to any applicable payment processing requirements."
  },
  {
    q: "Is the CV ATS-friendly?",
    a: "The templates are designed to use clean, machine-readable structures suitable for ATS systems."
  },
  {
    q: "Can I create a CV for another country?",
    a: "Yes. Select your target country before generating your CV."
  },
  { q: "Can I edit my CV?", a: "Yes. Users can review and edit their information before final generation." },
  {
    q: "Do you guarantee a job?",
    a: "No. CV1QAR helps create professional application documents but does not guarantee employment."
  }
];

export default function LandingPage() {
  return (
    <>
      <Header />
      <main>
        {/* Hero */}
        <section className="stamp-grain border-b border-ink-100 bg-paper">
          <div className="mx-auto max-w-4xl px-4 py-20 text-center sm:px-6 sm:py-28">
            <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-maroon-200 bg-maroon-50 px-4 py-1.5 font-mono text-xs uppercase tracking-widest text-maroon-600">
              1 QAR · Ready in minutes
            </span>
            <h1 className="font-display text-4xl font-semibold leading-tight text-ink-900 sm:text-6xl">
              Create Your Professional CV for Just <span className="text-maroon-500">1 QAR</span>
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-base text-ink-500 sm:text-lg">
              Build a professional, ATS-friendly CV tailored to the country and job market you&apos;re applying to.
            </p>
            <p className="mt-1 text-sm text-ink-400">
              Country-specific. ATS-friendly. Professional. Ready in minutes.
            </p>
            <div className="mt-8 flex justify-center">
              <Link
                href="/create"
                className="rounded-full bg-maroon-500 px-8 py-3.5 text-base font-semibold text-white shadow-stamp hover:bg-maroon-600"
              >
                Create My CV — 1 QAR
              </Link>
            </div>
            <ul className="mx-auto mt-10 grid max-w-2xl grid-cols-2 gap-3 text-left text-sm text-ink-600 sm:grid-cols-3">
              {[
                "Country-specific CV",
                "ATS-friendly formatting",
                "Professional templates",
                "AI-powered writing",
                "PDF download"
              ].map((item) => (
                <li key={item} className="flex items-start gap-2">
                  <span className="mt-0.5 text-maroon-500">✓</span>
                  {item}
                </li>
              ))}
            </ul>
            <p className="mt-10 font-mono text-xs uppercase tracking-widest text-ink-400">
              Simple. Fast. Affordable.
            </p>
          </div>
        </section>

        {/* How it works */}
        <section className="mx-auto max-w-5xl px-4 py-20 sm:px-6">
          <h2 className="mb-10 text-center font-display text-2xl font-semibold text-ink-900 sm:text-3xl">
            How it works
          </h2>
          <div className="grid gap-6 sm:grid-cols-3">
            {HOW_IT_WORKS.map((s, i) => (
              <div key={s.title} className="rounded-2xl border border-ink-100 bg-white p-6">
                <span className="font-mono text-xs text-maroon-500">0{i + 1}</span>
                <p className="mt-2 font-display text-lg font-semibold text-ink-900">{s.title}</p>
                <p className="mt-1 text-sm text-ink-500">{s.blurb}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Why CV1QAR */}
        <section className="border-y border-ink-100 bg-white py-20">
          <div className="mx-auto max-w-5xl px-4 sm:px-6">
            <h2 className="mb-10 text-center font-display text-2xl font-semibold text-ink-900 sm:text-3xl">
              Why CV1QAR
            </h2>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {WHY.map((w) => (
                <div key={w.title}>
                  <p className="font-display text-lg font-semibold text-ink-900">{w.title}</p>
                  <p className="mt-1 text-sm text-ink-500">{w.blurb}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Country support */}
        <section className="mx-auto max-w-5xl px-4 py-20 sm:px-6">
          <h2 className="mb-2 text-center font-display text-2xl font-semibold text-ink-900 sm:text-3xl">
            Built for your market
          </h2>
          <p className="mb-10 text-center text-sm text-ink-500">
            Each country has its own CV conventions built in — more markets added regularly.
          </p>
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-8">
            {COUNTRIES.map((c) => (
              <Link
                key={c.slug}
                href={`/cv/${c.slug}`}
                className="flex flex-col items-center gap-1 rounded-xl border border-ink-100 bg-white p-3 text-center hover:border-maroon-500"
              >
                <span className="text-2xl">{c.flag}</span>
                <span className="text-xs text-ink-600">{c.name}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* Templates */}
        <section className="border-y border-ink-100 bg-white py-20">
          <div className="mx-auto max-w-5xl px-4 sm:px-6">
            <h2 className="mb-10 text-center font-display text-2xl font-semibold text-ink-900 sm:text-3xl">
              Templates
            </h2>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {TEMPLATES.map((t) => (
                <div key={t.name} className="rounded-2xl border border-ink-100 p-5">
                  <div className="mb-3 h-32 rounded-lg bg-ink-50" />
                  <p className="font-display font-semibold text-ink-900">{t.name}</p>
                  <p className="text-xs text-ink-500">{t.blurb}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ATS explanation */}
        <section className="mx-auto max-w-3xl px-4 py-20 text-center sm:px-6">
          <h2 className="mb-4 font-display text-2xl font-semibold text-ink-900 sm:text-3xl">
            What does &ldquo;ATS-friendly&rdquo; mean?
          </h2>
          <p className="text-sm text-ink-500">
            Most employers scan CVs with Applicant Tracking Software before a human sees them. Our templates avoid
            tables, columns, and graphics that confuse this software — keeping your CV clean, structured, and fully
            readable by machines and recruiters alike.
          </p>
        </section>

        {/* Pricing */}
        <section className="border-y border-ink-100 bg-maroon-500 py-20 text-center text-white">
          <div className="mx-auto max-w-md px-4 sm:px-6">
            <p className="font-mono text-xs uppercase tracking-widest text-maroon-100">Pricing</p>
            <p className="mt-3 font-display text-5xl font-bold">1 QAR</p>
            <p className="mt-2 text-sm text-maroon-100">Per CV. No subscriptions. No hidden fees.</p>
            <Link
              href="/create"
              className="mt-6 inline-block rounded-full bg-white px-8 py-3 text-sm font-semibold text-maroon-600 hover:bg-maroon-50"
            >
              Create My CV — 1 QAR
            </Link>
          </div>
        </section>

        {/* FAQ */}
        <section className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
          <h2 className="mb-10 text-center font-display text-2xl font-semibold text-ink-900 sm:text-3xl">FAQ</h2>
          <div className="space-y-6">
            {FAQ.map((f) => (
              <div key={f.q} className="border-b border-ink-100 pb-6">
                <p className="font-semibold text-ink-900">{f.q}</p>
                <p className="mt-1 text-sm text-ink-500">{f.a}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Final CTA */}
        <section className="mx-auto max-w-3xl px-4 pb-24 text-center sm:px-6">
          <Link
            href="/create"
            className="inline-block rounded-full bg-maroon-500 px-8 py-3.5 text-base font-semibold text-white shadow-stamp hover:bg-maroon-600"
          >
            Create My CV — 1 QAR
          </Link>
        </section>
      </main>
      <Footer />
    </>
  );
}
