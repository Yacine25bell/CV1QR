"use client";

import React, { useEffect, useState } from "react";
import { Card } from "@/components/ui/Field";

interface Stats {
  totalCvs: number;
  paidCvs: number;
  failedPayments: number;
  revenueMinor: number;
  byCountry: Record<string, number>;
  byTemplate: Record<string, number>;
  recentOrders: Array<{ id: string; status: string; amountMinor: number; createdAt: string }>;
}

function Bar({ label, value, max }: { label: string; value: number; max: number }) {
  const pct = max ? Math.round((value / max) * 100) : 0;
  return (
    <div className="mb-2">
      <div className="mb-1 flex justify-between text-xs text-ink-500">
        <span className="capitalize">{label}</span>
        <span>{value}</span>
      </div>
      <div className="h-2 w-full rounded-full bg-ink-100">
        <div className="h-full rounded-full bg-maroon-500" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    fetch("/api/admin/stats")
      .then((r) => r.json())
      .then(setStats);
  }, []);

  if (!stats) return <div className="p-10 text-ink-400">Loading dashboard…</div>;

  const maxCountry = Math.max(1, ...Object.values(stats.byCountry));
  const maxTemplate = Math.max(1, ...Object.values(stats.byTemplate));

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
      <h1 className="mb-6 font-display text-2xl font-semibold text-ink-900">Admin dashboard</h1>

      <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          { label: "Total CVs Generated", value: stats.totalCvs },
          { label: "Paid CVs", value: stats.paidCvs },
          { label: "Failed Payments", value: stats.failedPayments },
          { label: "Revenue (QAR)", value: (stats.revenueMinor / 100).toFixed(2) }
        ].map((s) => (
          <Card key={s.label}>
            <p className="text-xs uppercase tracking-widest text-ink-400">{s.label}</p>
            <p className="mt-1 font-display text-2xl font-semibold text-ink-900">{s.value}</p>
          </Card>
        ))}
      </div>

      <div className="mb-8 grid gap-6 sm:grid-cols-2">
        <Card>
          <p className="mb-3 font-semibold text-ink-800">CVs by country</p>
          {Object.entries(stats.byCountry).length ? (
            Object.entries(stats.byCountry).map(([k, v]) => <Bar key={k} label={k} value={v} max={maxCountry} />)
          ) : (
            <p className="text-sm text-ink-400">No data yet.</p>
          )}
        </Card>
        <Card>
          <p className="mb-3 font-semibold text-ink-800">CVs by template</p>
          {Object.entries(stats.byTemplate).length ? (
            Object.entries(stats.byTemplate).map(([k, v]) => <Bar key={k} label={k} value={v} max={maxTemplate} />)
          ) : (
            <p className="text-sm text-ink-400">No data yet.</p>
          )}
        </Card>
      </div>

      <Card>
        <p className="mb-3 font-semibold text-ink-800">Recent orders</p>
        {stats.recentOrders.length ? (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-widest text-ink-400">
                <th className="pb-2">Order</th>
                <th className="pb-2">Status</th>
                <th className="pb-2">Amount</th>
                <th className="pb-2">Date</th>
              </tr>
            </thead>
            <tbody>
              {stats.recentOrders.map((o) => (
                <tr key={o.id} className="border-t border-ink-100">
                  <td className="py-2 font-mono text-xs">{o.id.slice(0, 8)}</td>
                  <td className="py-2 capitalize">{o.status}</td>
                  <td className="py-2">{(o.amountMinor / 100).toFixed(2)} QAR</td>
                  <td className="py-2 text-ink-400">{new Date(o.createdAt).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="text-sm text-ink-400">No orders yet.</p>
        )}
      </Card>

      <p className="mt-8 text-xs text-ink-400">
        Country rules, templates, and pricing management are planned admin features — see README for scope.
        Customer CV content is intentionally not shown here.
      </p>
    </div>
  );
}
