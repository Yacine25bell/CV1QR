"use client";

import React, { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { CvDraft, TemplateId } from "@/types";
import { localDraftStore } from "@/lib/storage";
import { track } from "@/lib/analytics";
import { Button } from "@/components/ui/Button";
import { CvRenderer } from "@/components/templates/CvRenderer";
import Link from "next/link";

type PayState = "idle" | "creating" | "awaiting" | "succeeded" | "failed";

const TEMPLATE_OPTIONS: Array<{ id: TemplateId; name: string }> = [
  { id: "ats-classic", name: "ATS Classic" },
  { id: "modern-professional", name: "Modern Professional" },
  { id: "executive", name: "Executive" },
  { id: "minimal", name: "Minimal" }
];

export default function PreviewPage() {
  const params = useSearchParams();
  const cvId = params.get("cvId");
  const [draft, setDraft] = useState<CvDraft | null>(null);
  const [zoom, setZoom] = useState(0.6);
  const [payState, setPayState] = useState<PayState>("idle");
  const [orderId, setOrderId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [agreed, setAgreed] = useState(false);

  useEffect(() => {
    const local = localDraftStore.load();
    if (local && local.id === cvId) {
      setDraft(local);
      return;
    }
    if (cvId) {
      fetch(`/api/cv/${cvId}`)
        .then((r) => (r.ok ? r.json() : null))
        .then(setDraft)
        .catch(() => setError("We couldn't load your CV. Please start again."));
    }
  }, [cvId]);

  function switchTemplate(id: TemplateId) {
    if (!draft) return;
    const next = { ...draft, templateId: id };
    setDraft(next);
    localDraftStore.save(next);
  }

  async function startPayment() {
    if (!draft) return;
    setPayState("creating");
    setError("");
    try {
      const res = await fetch("/api/payment/create", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ cvId: draft.id })
      });
      if (!res.ok) throw new Error("failed");
      const data = await res.json();
      setOrderId(data.order.id);
      localDraftStore.saveOrderId(data.order.id);
      track("payment_initiated", { countrySlug: draft.countrySlug, cvId: draft.id });
      setPayState("awaiting");
      // Mock provider: confirm immediately as if the user completed checkout.
      const confirmRes = await fetch("/api/payment/confirm", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ orderId: data.order.id, outcome: "succeeded" })
      });
      if (!confirmRes.ok) throw new Error("failed");
      setPayState("succeeded");
      track("payment_successful", { countrySlug: draft.countrySlug, cvId: draft.id });
    } catch {
      setPayState("failed");
      setError("Payment wasn't completed. You have not been charged. Please try again.");
    }
  }

  async function download() {
    if (!draft || !orderId) return;
    try {
      const res = await fetch(`/api/pdf?orderId=${orderId}&cvId=${draft.id}`);
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        throw new Error(data?.message || "download_failed");
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${(draft.personalInfo.fullName || "CV").replace(/\s+/g, "_")}_CV.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      track("download_completed", { countrySlug: draft.countrySlug, cvId: draft.id });
    } catch (e: any) {
      setError(e?.message || "Your CV was generated successfully, but we couldn't create the PDF yet. Please try again.");
    }
  }

  if (error && !draft) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <p className="mb-4 text-ink-700">{error}</p>
        <Link href="/create">
          <Button>Start Over</Button>
        </Link>
      </div>
    );
  }

  if (!draft) {
    return <div className="px-4 py-24 text-center text-ink-400">Loading your CV…</div>;
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:py-14">
      <div className="mb-8 text-center">
        <h1 className="font-display text-2xl font-semibold text-ink-900 sm:text-3xl">Your CV is ready.</h1>
        <p className="mt-1 text-sm text-ink-500">Review it below, switch templates, or make final edits.</p>
      </div>

      <div className="grid gap-8 lg:grid-cols-[220px_1fr]">
        <aside className="order-2 lg:order-1">
          <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-ink-400">Templates</p>
          <div className="flex gap-2 overflow-x-auto lg:flex-col lg:overflow-visible">
            {TEMPLATE_OPTIONS.map((t) => (
              <button
                key={t.id}
                onClick={() => switchTemplate(t.id)}
                className={`whitespace-nowrap rounded-xl border px-3 py-2 text-left text-sm ${
                  draft.templateId === t.id ? "border-maroon-500 bg-maroon-50 text-maroon-600" : "border-ink-100 text-ink-600"
                }`}
              >
                {t.name}
              </button>
            ))}
          </div>

          <p className="mb-2 mt-6 text-xs font-semibold uppercase tracking-widest text-ink-400">Zoom</p>
          <input
            type="range"
            min={0.4}
            max={1}
            step={0.05}
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
            className="w-full"
          />

          <Link href="/create" className="mt-6 block text-sm text-ink-500 underline underline-offset-4">
            Edit information
          </Link>
        </aside>

        <div className="order-1 flex justify-center overflow-x-auto rounded-2xl bg-ink-50 stamp-grain p-6 lg:order-2">
          <div style={{ transform: `scale(${zoom})`, transformOrigin: "top center" }}>
            <CvRenderer draft={draft} />
          </div>
        </div>
      </div>

      <div className="mx-auto mt-10 max-w-md rounded-2xl border border-ink-100 bg-white p-6 text-center shadow-stamp">
        {payState !== "succeeded" ? (
          <>
            <p className="mb-1 font-display text-lg font-semibold text-ink-900">
              Download your professional CV for only 1 QAR.
            </p>
            <p className="mb-4 text-sm text-ink-500">Secure payment. Instant PDF download.</p>
            <label className="mb-4 flex items-start gap-2 text-left text-xs text-ink-500">
              <input
                type="checkbox"
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                className="mt-0.5"
              />
              I agree to the{" "}
              <Link href="/privacy" className="underline underline-offset-2">
                Privacy Policy
              </Link>{" "}
              and{" "}
              <Link href="/terms" className="underline underline-offset-2">
                Terms of Service
              </Link>
              .
            </label>
            {error ? <p className="mb-3 text-sm text-maroon-500">{error}</p> : null}
            <Button
              fullWidth
              onClick={startPayment}
              disabled={!agreed || payState === "creating" || payState === "awaiting"}
            >
              {payState === "creating" || payState === "awaiting" ? "Processing…" : "Pay 1 QAR & Download"}
            </Button>
          </>
        ) : (
          <>
            <p className="mb-1 font-display text-lg font-semibold text-ink-900">Payment successful.</p>
            <p className="mb-4 text-sm text-ink-500">Your CV is unlocked and ready to download.</p>
            <Button fullWidth onClick={download}>
              Download CV
            </Button>
            {error ? <p className="mt-3 text-sm text-maroon-500">{error}</p> : null}
          </>
        )}
      </div>
    </div>
  );
}
