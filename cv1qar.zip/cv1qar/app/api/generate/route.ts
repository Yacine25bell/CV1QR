import { NextRequest, NextResponse } from "next/server";
import { AIService } from "@/services/AIService";
import { CVService } from "@/services/CVService";
import { CvDraft } from "@/types";

// All AI calls happen here, server-side, so AI_API_KEY is never exposed to
// the browser. The frontend only ever talks to this route.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const draft: CvDraft = body.draft;

    if (!draft) return NextResponse.json({ error: "missing_draft" }, { status: 400 });

    switch (body.type) {
      case "summary": {
        const result = await AIService.generateSummary(draft);
        return NextResponse.json({ result });
      }
      case "experience": {
        const exp = draft.experience.find((e) => e.id === body.experienceId);
        if (!exp) return NextResponse.json({ error: "experience_not_found" }, { status: 404 });
        const result = await AIService.polishExperience(draft, exp);
        return NextResponse.json(result);
      }
      case "skills": {
        const result = await AIService.suggestSkills(draft);
        return NextResponse.json({ result });
      }
      case "finalize": {
        // Persist the draft (creating it if this is the first time we've
        // seen this id) and compute a final ATS heuristic score.
        const existing = CVService.get(draft.id);
        const saved = existing ? CVService.save(draft) : CVService.create(draft);
        const atsScore = await AIService.checkAtsCompatibility(saved);
        CVService.save({ ...saved, atsScore });
        CVService.markCompleted(saved.id);
        return NextResponse.json({ ok: true, atsScore });
      }
      default:
        return NextResponse.json({ error: "unknown_type" }, { status: 400 });
    }
  } catch (err) {
    // Never leak internals to the client — the wizard shows a friendly
    // "we couldn't generate your CV right now" message on any non-2xx.
    return NextResponse.json({ error: "generation_failed" }, { status: 500 });
  }
}
