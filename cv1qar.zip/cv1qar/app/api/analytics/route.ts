import { NextRequest, NextResponse } from "next/server";
import { db } from "@/database/mockDb";

const ALLOWED_EVENTS = [
  "visitor",
  "country_selected",
  "cv_started",
  "cv_completed",
  "payment_initiated",
  "payment_successful",
  "download_completed"
];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!ALLOWED_EVENTS.includes(body.event)) {
      return NextResponse.json({ error: "unknown_event" }, { status: 400 });
    }
    db.track(body.event, { countrySlug: body.countrySlug, cvId: body.cvId });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false }, { status: 400 });
  }
}
