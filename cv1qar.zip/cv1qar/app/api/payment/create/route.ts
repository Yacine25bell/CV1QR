import { NextRequest, NextResponse } from "next/server";
import { PaymentService } from "@/services/PaymentService";
import { CVService } from "@/services/CVService";
import { db } from "@/database/mockDb";

export async function POST(req: NextRequest) {
  try {
    const { cvId } = await req.json();
    const draft = CVService.get(cvId);
    if (!draft) return NextResponse.json({ error: "cv_not_found" }, { status: 404 });

    const result = await PaymentService.createPayment(cvId);
    db.track("payment_initiated", { countrySlug: draft.countrySlug, cvId });
    return NextResponse.json(result);
  } catch {
    return NextResponse.json({ error: "payment_creation_failed" }, { status: 500 });
  }
}
