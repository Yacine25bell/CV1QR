import { NextRequest, NextResponse } from "next/server";
import { PaymentService } from "@/services/PaymentService";

// Stands in for a real gateway's hosted checkout page. In production this
// route disappears entirely — the user completes payment on the provider's
// page and PaymentService.handleWebhook() (server-to-server) is what
// actually flips the order to "succeeded", never the browser.
export async function POST(req: NextRequest) {
  try {
    const { orderId, outcome } = await req.json();
    if (!["succeeded", "failed", "cancelled"].includes(outcome)) {
      return NextResponse.json({ error: "invalid_outcome" }, { status: 400 });
    }
    const order = await PaymentService.simulateOutcome(orderId, outcome);
    return NextResponse.json({ order });
  } catch {
    return NextResponse.json({ error: "confirmation_failed" }, { status: 500 });
  }
}
