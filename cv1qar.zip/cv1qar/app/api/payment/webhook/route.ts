import { NextRequest, NextResponse } from "next/server";
import { PaymentService } from "@/services/PaymentService";

// Real payment providers call this endpoint directly (never the browser).
// The raw body is passed through unparsed so handleWebhook can verify the
// signature against PAYMENT_WEBHOOK_SECRET before trusting anything in it.
export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-payment-signature");
  const result = await PaymentService.handleWebhook(rawBody, signature);
  if (!result.ok) return NextResponse.json({ error: "invalid_signature" }, { status: 400 });
  return NextResponse.json({ received: true });
}
