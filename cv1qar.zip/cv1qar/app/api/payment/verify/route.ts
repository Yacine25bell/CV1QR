import { NextRequest, NextResponse } from "next/server";
import { PaymentService } from "@/services/PaymentService";

export async function GET(req: NextRequest) {
  const orderId = req.nextUrl.searchParams.get("orderId");
  if (!orderId) return NextResponse.json({ error: "missing_order_id" }, { status: 400 });
  const result = await PaymentService.verifyPayment(orderId);
  return NextResponse.json(result);
}
