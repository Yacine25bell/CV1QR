import { NextRequest, NextResponse } from "next/server";
import { v4 as uuidv4 } from "uuid";
import { PaymentService } from "@/services/PaymentService";
import { CVService } from "@/services/CVService";
import { PDFService } from "@/services/PDFService";
import { db } from "@/database/mockDb";

export async function GET(req: NextRequest) {
  const orderId = req.nextUrl.searchParams.get("orderId");
  const cvId = req.nextUrl.searchParams.get("cvId");
  if (!orderId || !cvId) {
    return NextResponse.json({ error: "missing_parameters" }, { status: 400 });
  }

  // The only thing that unlocks the PDF: a server-side re-check of payment
  // status. A client-supplied "paid=true" flag is never trusted.
  const { status, order } = await PaymentService.verifyPayment(orderId);
  if (status !== "succeeded" || !order || order.cvId !== cvId) {
    return NextResponse.json(
      { error: "payment_not_verified", message: "Payment wasn't completed. You have not been charged. Please try again." },
      { status: 402 }
    );
  }

  const draft = CVService.get(cvId);
  if (!draft) return NextResponse.json({ error: "cv_not_found" }, { status: 404 });

  try {
    const buffer = await PDFService.generate(draft);
    const filename = PDFService.filenameFor(draft);

    db.files.set(uuidv4(), {
      id: uuidv4(),
      orderId,
      cvId,
      filename,
      storagePath: `private/${orderId}/${filename}`, // never a publicly listable path
      createdAt: new Date().toISOString()
    });
    db.track("download_completed", { countrySlug: draft.countrySlug, cvId });

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        "content-type": "application/pdf",
        "content-disposition": `attachment; filename="${filename}"`
      }
    });
  } catch {
    return NextResponse.json(
      {
        error: "pdf_generation_failed",
        message: "Your CV was generated successfully, but we couldn't create the PDF yet. Please try again."
      },
      { status: 500 }
    );
  }
}
