import { NextRequest, NextResponse } from "next/server";
import { CVService } from "@/services/CVService";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const draft = CVService.get(params.id);
  if (!draft) return NextResponse.json({ error: "not_found" }, { status: 404 });
  return NextResponse.json(draft);
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await req.json();
    let draft = CVService.get(params.id);
    if (!draft) {
      draft = CVService.create({ ...body, id: params.id });
    } else {
      draft = CVService.save({ ...draft, ...body, id: params.id });
    }
    return NextResponse.json(draft);
  } catch {
    return NextResponse.json({ error: "invalid_request" }, { status: 400 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const draft = CVService.create(body);
    return NextResponse.json(draft);
  } catch {
    return NextResponse.json({ error: "invalid_request" }, { status: 400 });
  }
}
