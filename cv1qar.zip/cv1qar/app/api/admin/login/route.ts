import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";

// Minimal credential check for the MVP. Replace with a real admin_users
// table + hashed passwords (see database/schema.sql) before going live —
// ADMIN_USERNAME/ADMIN_PASSWORD env vars are a placeholder, not a real
// auth system.
export async function POST(req: NextRequest) {
  const { username, password } = await req.json();
  const validUser = process.env.ADMIN_USERNAME || "admin";
  const validPass = process.env.ADMIN_PASSWORD || "change-me";

  if (username !== validUser || password !== validPass) {
    return NextResponse.json({ error: "invalid_credentials" }, { status: 401 });
  }

  const secret = process.env.ADMIN_SESSION_SECRET || "change-me-too";
  const token = crypto.createHmac("sha256", secret).update(validUser).digest("hex");

  const res = NextResponse.json({ ok: true });
  res.cookies.set("cv1qar_admin", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 8
  });
  return res;
}
