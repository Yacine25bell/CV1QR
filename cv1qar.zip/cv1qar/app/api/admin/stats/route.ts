import { NextResponse } from "next/server";
import { db } from "@/database/mockDb";

// In production this route sits behind the admin auth middleware (see
// middleware.ts) — never expose per-customer CV content here, only
// aggregate counts.
export async function GET() {
  return NextResponse.json(db.stats());
}
