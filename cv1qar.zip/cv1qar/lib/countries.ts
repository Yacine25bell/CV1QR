import { Country } from "@/types";

// This list drives country selection, /cv/[country] SEO pages, and which
// file in /country-rules gets loaded. Add a new market by adding a row here
// AND a matching file in /country-rules, then registering it in
// country-rules/index.ts.
export const COUNTRIES: Country[] = [
  { code: "qa", slug: "qatar", name: "Qatar", flag: "🇶🇦", region: "gcc" },
  { code: "ae", slug: "uae", name: "United Arab Emirates", flag: "🇦🇪", region: "gcc" },
  { code: "sa", slug: "saudi-arabia", name: "Saudi Arabia", flag: "🇸🇦", region: "gcc" },
  { code: "kw", slug: "kuwait", name: "Kuwait", flag: "🇰🇼", region: "gcc" },
  { code: "bh", slug: "bahrain", name: "Bahrain", flag: "🇧🇭", region: "gcc" },
  { code: "om", slug: "oman", name: "Oman", flag: "🇴🇲", region: "gcc" },
  { code: "gb", slug: "uk", name: "United Kingdom", flag: "🇬🇧", region: "europe" },
  { code: "us", slug: "usa", name: "United States", flag: "🇺🇸", region: "north-america" },
  { code: "ca", slug: "canada", name: "Canada", flag: "🇨🇦", region: "north-america" },
  { code: "au", slug: "australia", name: "Australia", flag: "🇦🇺", region: "oceania" },
  { code: "de", slug: "germany", name: "Germany", flag: "🇩🇪", region: "europe" },
  { code: "fr", slug: "france", name: "France", flag: "🇫🇷", region: "europe" },
  { code: "nl", slug: "netherlands", name: "Netherlands", flag: "🇳🇱", region: "europe" },
  { code: "ie", slug: "ireland", name: "Ireland", flag: "🇮🇪", region: "europe" },
  { code: "es", slug: "spain", name: "Spain", flag: "🇪🇸", region: "europe" },
  { code: "it", slug: "italy", name: "Italy", flag: "🇮🇹", region: "europe" }
];

export function getCountryBySlug(slug: string): Country | undefined {
  return COUNTRIES.find((c) => c.slug === slug);
}

export const FEATURED_COUNTRY_SLUGS = ["qatar", "uae", "saudi-arabia", "uk", "usa", "canada"];
