"use client";

// Deliberately minimal: event name + country slug + cv id only. No names,
// emails, phone numbers, or CV content ever leave the client through this
// path. See app/api/analytics/route.ts and database/schema.sql
// (analytics_events) for where this lands.
export type AnalyticsEvent =
  | "visitor"
  | "country_selected"
  | "cv_started"
  | "cv_completed"
  | "payment_initiated"
  | "payment_successful"
  | "download_completed";

export function track(event: AnalyticsEvent, extra: { countrySlug?: string; cvId?: string } = {}) {
  try {
    const body = JSON.stringify({ event, ...extra });
    if (navigator.sendBeacon) {
      navigator.sendBeacon("/api/analytics", body);
    } else {
      fetch("/api/analytics", { method: "POST", body, keepalive: true }).catch(() => {});
    }
  } catch {
    // Analytics must never break the user's flow.
  }
}
