"use client";

import { CvDraft } from "@/types";

const DRAFT_KEY = "cv1qar:draft";
const CV_ID_KEY = "cv1qar:cv-id";
const STEP_KEY = "cv1qar:step";

// The wizard writes here on every change so an accidental refresh never
// loses the user's information — no account or login required for the MVP.
export const localDraftStore = {
  save(draft: CvDraft) {
    try {
      window.localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
    } catch {
      // Storage can fail (private browsing, quota) — never block the flow.
    }
  },
  load(): CvDraft | null {
    try {
      const raw = window.localStorage.getItem(DRAFT_KEY);
      return raw ? (JSON.parse(raw) as CvDraft) : null;
    } catch {
      return null;
    }
  },
  clear() {
    try {
      window.localStorage.removeItem(DRAFT_KEY);
      window.localStorage.removeItem(CV_ID_KEY);
      window.localStorage.removeItem(STEP_KEY);
    } catch {
      /* noop */
    }
  },
  saveStep(step: string) {
    try {
      window.localStorage.setItem(STEP_KEY, step);
    } catch {
      /* noop */
    }
  },
  loadStep(): string | null {
    try {
      return window.localStorage.getItem(STEP_KEY);
    } catch {
      return null;
    }
  },
  saveOrderId(orderId: string) {
    try {
      window.localStorage.setItem("cv1qar:order-id", orderId);
    } catch {
      /* noop */
    }
  },
  loadOrderId(): string | null {
    try {
      return window.localStorage.getItem("cv1qar:order-id");
    } catch {
      return null;
    }
  }
};
