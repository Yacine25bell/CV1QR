import { CvDraft, Order, GeneratedFile } from "@/types";

// ---------------------------------------------------------------------------
// Mock database — an in-memory stand-in for PostgreSQL/Supabase so the MVP
// runs with zero external setup. Every table in database/schema.sql has a
// matching Map here. Swap this module for real repository classes backed by
// `DATABASE_URL` when ready; nothing outside /database and /services should
// need to change, since routes only ever import `db` from this file.
//
// NOTE: this resets on every server restart / serverless cold start. It is
// only meant to make the wizard → payment → PDF flow demonstrably work
// end-to-end locally.
// ---------------------------------------------------------------------------

class MockDb {
  cvs = new Map<string, CvDraft>();
  orders = new Map<string, Order>();
  files = new Map<string, GeneratedFile>();
  analytics: Array<{ event: string; countrySlug?: string; cvId?: string; at: string }> = [];

  track(event: string, extra: { countrySlug?: string; cvId?: string } = {}) {
    this.analytics.push({ event, ...extra, at: new Date().toISOString() });
  }

  stats() {
    const totalCvs = this.cvs.size;
    const ordersList = Array.from(this.orders.values());
    const paid = ordersList.filter((o) => o.status === "succeeded");
    const failed = ordersList.filter((o) => o.status === "failed" || o.status === "cancelled");
    const revenueMinor = paid.reduce((sum, o) => sum + o.amountMinor, 0);

    const byCountry: Record<string, number> = {};
    const byTemplate: Record<string, number> = {};
    this.cvs.forEach((cv) => {
      byCountry[cv.countrySlug] = (byCountry[cv.countrySlug] || 0) + 1;
      byTemplate[cv.templateId] = (byTemplate[cv.templateId] || 0) + 1;
    });

    const recentOrders = ordersList
      .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
      .slice(0, 10)
      .map((o) => ({
        id: o.id,
        status: o.status,
        amountMinor: o.amountMinor,
        createdAt: o.createdAt
      }));

    return {
      totalCvs,
      paidCvs: paid.length,
      failedPayments: failed.length,
      revenueMinor,
      byCountry,
      byTemplate,
      recentOrders
    };
  }
}

// A single shared instance per server process (fine for the MVP / dev).
declare global {
  // eslint-disable-next-line no-var
  var __cv1qarDb: MockDb | undefined;
}

export const db = global.__cv1qarDb ?? new MockDb();
global.__cv1qarDb = db;
