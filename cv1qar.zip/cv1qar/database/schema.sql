-- ---------------------------------------------------------------------------
-- CV1QAR database schema (PostgreSQL / Supabase)
-- Mirrors the shapes in /types/index.ts. Apply with:
--   psql "$DATABASE_URL" -f database/schema.sql
-- ---------------------------------------------------------------------------

create extension if not exists "uuid-ossp";

create table if not exists users (
  id uuid primary key default uuid_generate_v4(),
  email text unique,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  referral_code text unique,
  referred_by text references users(referral_code),
  deleted_at timestamptz -- soft delete, supports "delete my data"
);

create table if not exists countries (
  slug text primary key,
  code text not null,
  name text not null,
  flag text not null,
  region text not null,
  active boolean not null default true
);

create table if not exists country_rules (
  country_slug text primary key references countries(slug) on delete cascade,
  priority_sections jsonb not null default '[]',
  optional_personal_fields jsonb not null default '[]',
  discouraged_fields jsonb not null default '[]',
  convention_summary text not null default '',
  ai_prompt_guidance text not null default '',
  default_template_id text not null default 'ats-classic',
  updated_at timestamptz not null default now()
);

create table if not exists templates (
  id text primary key, -- e.g. 'ats-classic'
  name text not null,
  description text,
  preview_image_url text,
  active boolean not null default true
);

create table if not exists cvs (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references users(id) on delete set null,
  country_slug text not null references countries(slug),
  cv_type text not null,
  template_id text not null references templates(id),
  personal_info jsonb not null default '{}',
  summary text default '',
  summary_mode text default 'manual',
  ats_score integer,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists cv_sections (
  id uuid primary key default uuid_generate_v4(),
  cv_id uuid not null references cvs(id) on delete cascade,
  section_type text not null, -- 'experience' | 'education' | 'skills' | 'certification' | 'additional'
  position integer not null default 0,
  data jsonb not null default '{}'
);

create table if not exists orders (
  id uuid primary key default uuid_generate_v4(),
  cv_id uuid not null references cvs(id) on delete cascade,
  amount_minor integer not null default 100, -- 1.00 QAR
  currency text not null default 'QAR',
  status text not null default 'pending', -- pending | succeeded | failed | cancelled
  payment_provider text not null,
  provider_reference text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists payments (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references orders(id) on delete cascade,
  provider text not null,
  provider_event_id text,
  status text not null,
  raw_payload jsonb,
  created_at timestamptz not null default now()
);

create table if not exists generated_files (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references orders(id) on delete cascade,
  cv_id uuid not null references cvs(id) on delete cascade,
  filename text not null,
  storage_path text not null, -- private bucket path, never publicly listable
  created_at timestamptz not null default now(),
  expires_at timestamptz
);

create table if not exists analytics_events (
  id uuid primary key default uuid_generate_v4(),
  event_name text not null, -- visitor | country_selected | cv_started | cv_completed | payment_initiated | payment_successful | download_completed
  country_slug text,
  cv_id uuid,
  session_id text,
  created_at timestamptz not null default now()
);

create table if not exists admin_users (
  id uuid primary key default uuid_generate_v4(),
  username text unique not null,
  password_hash text not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_cvs_country on cvs(country_slug);
create index if not exists idx_orders_status on orders(status);
create index if not exists idx_orders_cv on orders(cv_id);
create index if not exists idx_analytics_event_name on analytics_events(event_name);
